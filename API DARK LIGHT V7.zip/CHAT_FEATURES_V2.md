# Chat API V2

Added endpoints:
- GET /api/chat/profile
- POST /api/chat/profile (multipart field: avatar)
- POST /api/chat/edit
- POST /api/chat/delete
- POST /api/chat/private/edit
- POST /api/chat/private/delete

Profile editing is server-authorized for reseller/partner/tk/moderator/owner/admin/developer.
Message edit is limited to the sender and text messages. Message delete is limited to the sender, with owner/admin/developer allowed to moderate global messages.
